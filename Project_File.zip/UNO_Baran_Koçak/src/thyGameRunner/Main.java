/************** Pledge of Honor ******************************************
I hereby certify that I have completed this programming project on my own
without any help from anyone else. The effort in the project thus belongs
completely to me. I did not search for a solution, or I did not consult any
program written by others or did not copy any program from other sources. I
read and followed the guidelines provided in the project description.
READ AND SIGN BY WRITING YOUR NAME SURNAME AND STUDENT ID
SIGNATURE: Baran Koçak 86703
*************************************************************************/

package thyGameRunner;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import frames.LoginScreen;

public class Main {
	
	/**
	 * main method
	 * opens login screen
	 * 
	 * @param args ...
	 */
	public static void main(String[] args) {
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter("users.txt",true));
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		LoginScreen loginScreen = new LoginScreen();
		loginScreen.setVisible(true);
	}
	
	
}