package thyGameRunner;

import java.util.ArrayList;
import java.util.Collections;

import javax.swing.JPanel;

import accountManagement.AccountWizard;
import cards.Card;
import frames.BotStatusPanel;
import frames.GameSession;
import frames.MainMenu;
import gameCharacters.Bot;
import gameCharacters.GameCharacter;
import gameCharacters.Player;
import gameManagement.DeckManager;

public class GameMaster {

	
	private int botCount;
	private ArrayList<GameCharacter> characterList;
	private ArrayList<Card> deck;
	private DeckManager deckManager;
	private String sessionName;
	private MainMenu disposalMainMenu;
	private GameSession gameSession;
	private Player player;
	private int turnIndex;
	private static final int startingHandSize = 7;
	private String log;
	
	

	public GameMaster(Player player, int botCount, String sessionName) {
		
		this.botCount = botCount;
		addCharactersToList(player, botCount);
		deckManager = new DeckManager(this);
		deck = deckManager.generateDeck();
		this.sessionName = sessionName;
		turnIndex = 0;
		log = "";
		AccountWizard.addGameToUserDatabase(player.getName(), sessionName);
	}
	/**
	 * 
	 * instantiates game
	 * 
	 * everyone draws 7 cards
	 * creates characters
	 */
	private void instantiateGame() {
		
		
		disposalMainMenu.dispose();
		
		gameSession = new GameSession(this,sessionName);
		gameSession.setVisible(true);
		
		
		addRequiredComponentsToCards();
		Collections.shuffle(deck);
		JPanel playersHand = gameSession.getPlayersCards();
		
		/**** INSTANTIATE GAME ****/
		for (GameCharacter gameCharacter : characterList) {
			
			deckManager.drawCard(startingHandSize, gameCharacter, playersHand, gameSession.getDeckSizeText());
			
			if (gameCharacter.getClass().getSimpleName().equals("Bot")) {
				
				BotStatusPanel botPanel = new BotStatusPanel(gameCharacter);
				gameSession.getBotDisplay().add(botPanel);
				gameCharacter.setMyBotPanel(botPanel);
				gameCharacter.setGameMaster(this);
				
			}
		}
		
	 	gameSession.setLastPlayedCard(deckManager.discardFirstCardOfDeck(gameSession.getDeckSizeText()));
		
	}
	
	/**
	 * 
	 * runs the game :)
	 */
	public void runGame() { 
		
		instantiateGame();
		
	    
	}
	
	/**
	 * runs the saved game
	 * 
	 * @param topCard the top card of deck
	 */
	public void runSavedGame(Card topCard) {
		
		disposalMainMenu.dispose();
		
		
		gameSession.setVisible(true);
		
		
		addRequiredComponentsToCards();
		Collections.shuffle(deck);
		
		/**** INSTANTIATE GAME ****/
		for (GameCharacter gameCharacter : characterList) {
			
			
			
			if (gameCharacter.getClass().getSimpleName().equals("Bot")) {
				
				BotStatusPanel botPanel = new BotStatusPanel(gameCharacter);
				gameSession.getBotDisplay().add(botPanel);
				gameCharacter.setMyBotPanel(botPanel);
				gameCharacter.setGameMaster(this);
				
			}
		}
		
	 	gameSession.setLastPlayedCard(topCard);
	 	
	 	System.out.println(characterList.get(0).getCardsInHand());
	 	System.out.println(characterList.get(1).getCardsInHand());
		
	}
	
	
	
	
	
	
	
	
	/**
	 * sets the character list
	 * 
	 * @param player the user
	 * @param botCount bot count
	 */
	public void addCharactersToList(Player player, int botCount) {
		
		characterList = new ArrayList<>();
		characterList.add(player);
		this.player = player;
		
		for (int i = 0; i < botCount; i++) {
			
			characterList.add(new Bot(i));
		}
		
//		System.out.println("Characters: " + characterList);
	}
	
	
	/**
	 * adds required components
	 * 
	 */
	public void addRequiredComponentsToCards() {
		
		for (Card card : deck) {
			
			card.setPlayField(gameSession.getPlayField());
			card.setPlayersCards(gameSession.getPlayersCards());
			card.setPlayer(player);
			card.setGameMaster(this);
		}
		
	}

	
	/**
	 * adds log
	 * 
	 * @param msg the string that is going to be added
	 */
	public void appendLog(String msg) {
		
		if (log == "") log += msg;
		else log += "\n" + msg;
	}
	
	
	
	/**
	 * refreshes mainmenu
	 * 
	 * @param mainMenu the main menu
	 * @param username the name of the user
	 */
	public static void refreshMainMenu(MainMenu mainMenu, String username) {
		
		mainMenu.dispose();
		MainMenu newFrame = new MainMenu(username);
		newFrame.setVisible(true);
		
	}
	
	
	
	
	
	
	
	public int getDeckSize() {
		
		return deck.size();
	}
	
	
	public int getBotCount() {
		return botCount;
	}

	public void setBotCount(int botCount) {
		this.botCount = botCount;
	}

	public ArrayList<GameCharacter> getCharacterList() {
		return characterList;
	}

	public void setCharacterList(ArrayList<GameCharacter> characterList) {
		this.characterList = characterList;
	}


	public ArrayList<Card> getDeck() {
		return deck;
	}


	public void setDeck(ArrayList<Card> deck) {
		this.deck = deck;
	}


	public DeckManager getDeckManager() {
		return deckManager;
	}


	public void setDeckManager(DeckManager deckManager) {
		this.deckManager = deckManager;
	}


	public String getSessionName() {
		return sessionName;
	}


	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}
	
	

	public MainMenu getDisposalMainMenu() {
		return disposalMainMenu;
	}


	public void setDisposalMainMenu(MainMenu disposalMainMenu) {
		this.disposalMainMenu = disposalMainMenu;
	}

	public GameSession getGameSession() {
		return gameSession;
	}

	public void setGameSession(GameSession gameSession) {
		this.gameSession = gameSession;
	}

	public Player getPlayer() {
		return player;
	}

	public void setPlayer(Player player) {
		this.player = player;
	}

	public int getTurnIndex() {
		while (turnIndex < 0) {
			turnIndex += characterList.size();
		}
		
		turnIndex = turnIndex % characterList.size();
		return turnIndex;
	}

	/**
	 * makes is it so that it doesnt go out of bounds
	 * 
	 * @param turnIndex the turn that currently in
	 */
	public void setTurnIndex(int turnIndex) {
//		if (turnIndex < 0) {
			while (turnIndex < 0) {
				turnIndex += characterList.size();
			}
//		}
			
			turnIndex = turnIndex % characterList.size();
			
		this.turnIndex = turnIndex;
	}

	public String getLog() {
		return log;
	}

	public void setLog(String log) {
		this.log = log;
	}
	
	
	
	

}
