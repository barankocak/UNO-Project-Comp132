package gameCharacters;

import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import accountManagement.AccountWizard;
import cards.Card;
import cards.DrawFourWildCard;
import cards.DrawTwoCard;
import cards.NumberCard;
import cards.ReverseCard;
import cards.SimpleWildCard;
import cards.SkipCard;
import frames.BotStatusPanel;
import frames.MainMenu;
import thyGameRunner.GameMaster;

public abstract class GameCharacter {
	
	protected ArrayList<Card> cardsInHand;
	protected int totalPoints;
	protected boolean myTurn;
	protected String name;
	protected BotStatusPanel myBotPanel;
	protected GameMaster gameMaster;
	protected int turnIndex;
	protected boolean isUNO;
	
	
	public GameCharacter(String name, int turnIndex) {
		
		cardsInHand = new ArrayList<>();
		totalPoints = 0;
		myTurn = false;
		this.name = name;
		this.turnIndex = turnIndex;
		isUNO = false;
		
		
	}


	/**
	 * makes character win the game
	 * popps info message and then return to mainmenu
	 * updates log file
	 * 
	 */
	public void win() {
		
		
		
		for (int i = 0; i < gameMaster.getCharacterList().size(); i++) {
			
			GameCharacter nextCaracter = gameMaster.getCharacterList().get(i);
			
			if (nextCaracter.equals(this)) {
				continue;
			}
			else {
				
				for (int j = 0; j < nextCaracter.getCardsInHand().size(); j++) {
					
					Card nextCard = nextCaracter.getCardsInHand().get(j);
					
					totalPoints += nextCard.getScoreValue();
				}
				
			}
		}
		
		
		JLabel winner = new JLabel(name + " --> WON!");
		gameMaster.getGameSession().getPlayField().add(winner);
		winner.revalidate();
		winner.repaint();
		gameMaster.appendLog(winner.getText());
		
		Object[] options = {"fine"};

		int choice = JOptionPane.showOptionDialog(null, name + " IS THE WINNNEEEERRRRR WITH " + totalPoints + " POINTS!!!!", "SOOOO THE WINNER IISSSSSSS", JOptionPane.DEFAULT_OPTION, 
				JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

		if (choice == JOptionPane.OK_OPTION) {
			MainMenu mainMenu = new MainMenu(gameMaster.getCharacterList().get(0).getName());
			mainMenu.setVisible(true);
			
			gameMaster.getGameSession().dispose();
			
		}
		
		
		if (this instanceof Player) {
			
			AccountWizard.updateStatsFileForUser(gameMaster.getPlayer().getName(),true,totalPoints);
		}
		else {
			
			AccountWizard.updateStatsFileForUser(gameMaster.getPlayer().getName(),false,0);
		}
		
		AccountWizard.addLogToUserDatabase(gameMaster.getPlayer().getName(), gameMaster.getSessionName(), gameMaster.getLog());
	}

	/**
	 * penalises this character because it didn't say uno
	 * 
	 * @param punisher the one who caught
	 */
	public void penaltize(String punisher) {
		
		JLabel explainor = new JLabel();
		JLabel narrator = new JLabel();
		
		explainor.setText(punisher + " caught " + name + "!");
		narrator.setText(name + " --> must draw twice");
		
		Font boldFont = new Font(explainor.getFont().getName(), Font.BOLD, explainor.getFont().getSize());
		Font italicFont = new Font(explainor.getFont().getName(), Font.ITALIC, explainor.getFont().getSize());
		
		explainor.setFont(boldFont);
		narrator.setFont(italicFont);
		
		gameMaster.getGameSession().getPlayField().add(explainor);
		gameMaster.getGameSession().getPlayField().add(narrator);

		explainor.revalidate();
		narrator.revalidate();
		
		explainor.repaint();
		narrator.repaint();
		
		gameMaster.appendLog(explainor.getText());
		gameMaster.appendLog(narrator.getText());
		
		Card[] cardd = gameMaster.getDeckManager().drawCard(2, this, gameMaster.getGameSession().getPlayersCards(), gameMaster.getGameSession().getDeckSizeText());
		if (this instanceof Bot )myBotPanel.updateHandSizeText();
	}
	
	/**
	 * says uno
	 */
	public void sayUNO() {
		
		JLabel unoo = new JLabel(name + "--> UNO!");
		unoo.setFont(new Font(unoo.getFont().getName(), Font.BOLD, unoo.getFont().getSize()));
		gameMaster.getGameSession().getPlayField().add(unoo);
		unoo.revalidate();
		unoo.repaint();
		gameMaster.appendLog(unoo.getText());
		isUNO = true;
	}
	
	public String stringifyHand() {
		
		String cardString = "";
		
		for (int i = 0; i < cardsInHand.size(); i++) {
			
			Card card = cardsInHand.get(i);
			
			
			if (card.getColorString().equals("blue")) cardString += "B";
			else if (card.getColorString().equals("red")) cardString += "R";
			else if (card.getColorString().equals("yellow")) cardString += "Y";
			else if (card.getColorString().equals("green")) cardString += "G";
			else cardString += "W";
			
			if (card instanceof NumberCard) cardString += card.getNum();
			else if (card instanceof ReverseCard) cardString += "G";		// reverseCard = "G"
			else if (card instanceof SkipCard) cardString += "S";			// skipCard = "S"
			else if (card instanceof DrawTwoCard) cardString += "T";		// drawTwo  = "T"
			else if (card instanceof SimpleWildCard) cardString += "J";		// simpleWild = "J"
			else if (card instanceof DrawFourWildCard) cardString += "F";	// drawFour = "F"
			
			if (i != cardsInHand.size() - 1) cardString += "∑";
			
			
		}
		
		
		
		return cardString;
	}
	
	
	
	
	public void addToHand(Card card) {
		
		cardsInHand.add(card);
	}
	
	public boolean isMyTurn() {
		
		return myTurn;
		
	}
	
	
	
	
	
	
	public ArrayList<Card> getCardsInHand() {
		return cardsInHand;
	}

	public void setCardsInHand(ArrayList<Card> cardsInHand) {
		this.cardsInHand = cardsInHand;
	}
	public int getPoints() {
		return totalPoints;
	}
	public void setPoints(int points) {
		this.totalPoints = points;
	}





	public String getName() {
		return name;
	}





	public void setName(String name) {
		this.name = name;
	}





	public void setMyTurn(boolean myTurn) {
		this.myTurn = myTurn;
	}





	public BotStatusPanel getMyBotPanel() {
		return myBotPanel;
	}





	public GameMaster getGameMaster() {
		return gameMaster;
	}





	public void setGameMaster(GameMaster gameMaster) {
		this.gameMaster = gameMaster;
	}





	public int getTurnIndex() {
		return turnIndex;
	}





	public void setTurnIndex(int turnIndex) {
		this.turnIndex = turnIndex;
	}





	public boolean isUNO() {
		return isUNO;
	}





	public void setUNO(boolean isUNO) {
		this.isUNO = isUNO;
	}





	public void setMyBotPanel(BotStatusPanel botStatusPanel) {
		this.myBotPanel = botStatusPanel;
	}
	
	
	

}
