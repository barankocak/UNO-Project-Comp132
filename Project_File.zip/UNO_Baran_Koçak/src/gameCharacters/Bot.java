package gameCharacters;



import javax.swing.JPanel;

import cards.Card;
import frames.GameSession;
import gameManagement.DeckManager;
public class Bot extends GameCharacter{
	

//	protected ArrayList<Card> cardsInHand;
//	protected int points;
//	protected boolean myTurn;
//	protected String name;
//	protected BotStatusPanel myBotPanel;
//	protected GameMaster gameMaster;
//	protected int turnIndex;
	
	
	public Bot(int index) {
		
		super("Bot-" + ++index, index + 1);
//		myBotPanel = 
	}
	
	/**
	 * bot plays turn
	 * says uno 60%
	 * declares win if wins
	 * 
	 * @param deckManager manages deck
	 */
	public void playTurn(DeckManager deckManager) {
		
		isUNO = false;
		
		gameMaster = deckManager.getGameMaster();
		GameSession gameSession = gameMaster.getGameSession();
		JPanel playersHand = gameSession.getPlayersCards();
		
		
		boolean succesfull = false;
    	
    	for (int i = 0; i < cardsInHand.size(); i++) {
    		
    		Card cardInHand = cardsInHand.get(i);
    		
    		if (cardInHand.isPlayable()) {
    			
    			gameSession.setLastPlayedCard(cardInHand); 
    			cardInHand.playBotsCard(this);
    			succesfull = true;
    			break;
    		}
    	}
    	
    	if (!succesfull) {
    		
    		Card[] drawnCards = deckManager.drawCard(1, this, playersHand, gameSession.getDeckSizeText());
    		Card drawnCard = drawnCards[0];
    		drawnCard.imDrawn(this, 1);
    		if (drawnCard.isPlayable()) {
    			
    			gameSession.setLastPlayedCard(drawnCard); 
    			drawnCard.playBotsCard(this);
    		}
    		myBotPanel.updateHandSizeText();
    	}
    	
    	if (cardsInHand.size() == 1) {
    		
    		if (Math.random() < 0.6) {
    			
    			
				sayUNO();
				
    		}
    		else isUNO = false;
    	}
    	else isUNO = false;
    	
    	if (cardsInHand.size() == 0) {
    		
    		win();
    	}
		
		
        
        
		
	}
	
	
	
	
	
	
	
	@Override
	public String toString() {
		
		return name;
	}
	
	

}
