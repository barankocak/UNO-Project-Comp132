package gameCharacters;

public class Player extends GameCharacter{
	
	private boolean hasPlayed;
	
	
	
	
	public Player(String name) {
		
		super(name, 0);
		hasPlayed = false;
		myTurn = true;
	}
	
	@Override
	public String toString() {
		
		return name;
	}

	public boolean isHasPlayed() {
		return hasPlayed;
	}

	public void setHasPlayed(boolean hasPlayed) {
		this.hasPlayed = hasPlayed;
	}

	
	
}
