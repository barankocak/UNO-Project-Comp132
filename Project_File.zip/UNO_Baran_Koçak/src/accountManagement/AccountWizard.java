package accountManagement;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import cards.Card;
import frames.GameSession;
import gameCharacters.GameCharacter;
import gameCharacters.Player;
import gameManagement.DeckManager;
import thyGameRunner.GameMaster;


/**
 * Account wizard is a class that handles .txt file realted code
 */
public class AccountWizard {
	
	
	
	private static BufferedWriter writer;
	private static BufferedReader reader;
	
	/**
	 * This method registers
	 * 
	 * @param username is the username the user wants to register with
	 * @param password is the password the user wants to register with
	 */
	
	public void register(String username, String password) {
		
		try {
			
			writer = new BufferedWriter(new FileWriter("users.txt",true));
			writer.write(username + "∑" + password + "\n");
			writer.flush();
			
			
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			
			try {
				if (writer != null) writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		createFoldersForUser(username);
	}
	
	/**
	 * This method lets the player login
	 * 
	 * @param username is the username the user wants to login with
	 * @param password is the password the user wants to login with
	 * @return returns true if the login was succesfull else false
	 */
	
	
	public boolean login(String username, String password) {
		
		String currentUsername = "";
		String currentPassword = "";
		boolean result = true;
		
		try {
			reader = new BufferedReader(new FileReader("users.txt"));
			
			while(!currentUsername.equals(username)) {
				
				currentUsername = "";
				currentPassword = "";
				String currentLine = reader.readLine();
				
				if (currentLine == null) {
					
					result = false;
					break;
				}
				
				String[] info = currentLine.split("∑");
				
				currentUsername = info[0];
				currentPassword = info[1];
				
				
				
				if (currentUsername.equals(username)) {
					
					
					if (currentPassword.equals(password)) {
						
						result = true;
					}
					else {
						
						
						result = false;
						
					}
				}
			}
			
			
			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
		}
		
		return result;
		
		
	}
	
	/**
	 * This method checks if the username is registered
	 * 
	 * @param username is the username registered
	 * @return true if the username is registered
	 */
	
	public boolean isRegistered(String username) {
		
		String currentUsername = "";
		String currentLine;
		boolean result = true;
		
		try {
			reader = new BufferedReader(new FileReader("users.txt"));
			
			while(!currentUsername.equals(username)) {
				currentUsername = "";
				currentLine = reader.readLine();
				
				if (currentLine == null) {
					
					result = false;
					break;
				}
				
				String[] info = currentLine.split("∑");
				
				currentUsername = info[0];
			}
			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
		}
		
		return result;
		
		
	}
	/**
	 * Returns all usernames recorded
	 * @return all usernames recorded
	 */
	
	public static ArrayList<String> getUsernames(){

		
		ArrayList<String> usernames = new ArrayList<>();
		
		String currentUsername = "";
		String currentLine;
		
		try {
			reader = new BufferedReader(new FileReader("users.txt"));
			
			currentLine = reader.readLine();
			int ii = 0;
			while(currentLine != null) {
				currentUsername = "";
				if(ii != 0) currentLine = reader.readLine();
				
				
				if (currentLine == null) break;
				
				String[] info = currentLine.split("∑");
				currentUsername = info[0];
				
				ii++;
				usernames.add(currentUsername);
			}
			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
		
		
		return usernames;
	}
	/**
	 * Handles folder creation for the given username
	 * @param username is the owners username
	 */

	public void createFoldersForUser(String username) {
		
		File userFolder = new File(username);
		boolean isSuccesfull = userFolder.mkdir();
		
		if (isSuccesfull) {
			
			System.out.println("user folder creation is succesfull");
		}
		else {
			
			System.out.println("user folder creation is unsuccesfull");
		}
		
		
		File savesFolder = new File(username,"saves");
		isSuccesfull = savesFolder.mkdir();
		
		if (isSuccesfull) {
			
			System.out.println("saves folder creation is succesfull");
		}
		else {
			
			System.out.println("saves folder creation is unsuccesfull");
		}
		
		updateStatsFileForUser(username, true, -1);
		
		
	}
	/**
	 * Updates stats.txt for the user. Uses ∑ as seperator to store in the same line.
	 * 
	 * @param username is the name of the user
	 * @param isWin did the user win if so true
	 * @param earntPoints how many point did the player earn
	 */

	public static void updateStatsFileForUser(String username, boolean isWin, int earntPoints) {
		
		if (earntPoints < 0) {
			
			try {
				writer = new BufferedWriter(new FileWriter(username + File.separator +  "stats.txt",true));
				writer.write("\n");
				writer.flush();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				
				try {
					if (writer != null) writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			return;
			
			
		}
		
		
		
		String firstLine = "";
		String secondLine = "";
		
		try {
			
			File file = new File(username + File.separator + "stats.txt");
			
			if (!file.exists()) {
				
				writer = new BufferedWriter(new FileWriter(username + File.separator +  "stats.txt",true));
				writer.write("\n");
				writer.flush();
				writer.close();
			}
			
			
			reader = new BufferedReader(new FileReader(username + File.separator + "stats.txt"));
			
			firstLine = reader.readLine(); // win/lose
			secondLine = reader.readLine(); // points
			
			reader.close();
			
			if (secondLine == null) secondLine = "";
			
			if (firstLine.length() != 0) firstLine += "∑" + (isWin ? 1 : 0);
			else firstLine += isWin ? 1 : 0;
			
			if (secondLine.length() != 0) secondLine += "∑" + earntPoints;
			else secondLine += earntPoints;
			
			writer = new BufferedWriter(new FileWriter(username + File.separator +  "stats.txt",false));
			writer.write(firstLine);
			writer.write("\n");
			writer.write(secondLine);
			writer.flush();
			
			
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			
			try {
				if (writer != null) writer.close();
				if (reader != null) reader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	/**
	 * adds played game to database
	 * 
	 * @param username the name of the user
	 * @param sessionName the name of the session
	 */
	
	public static void addGameToUserDatabase(String username, String sessionName) {
		
		File newGameFolder = new File(username + File.separator + "saves" + File.separator + sessionName);
		boolean isSuccesfull = newGameFolder.mkdir();
		
		
		if (isSuccesfull) {
			
			System.out.println("new game folder creation succesfull");
		}
		else {
			
			System.out.println("new game folder creation unsuccesfull");
		}
	}
	
	/**
	 * adds log to the database
	 * 
	 * @param username name of the user
	 * @param sessionName name of the session
	 * @param log is a long string that contains what happened in the game
	 */
	
	public static void addLogToUserDatabase(String username, String sessionName, String log) {
		
		try {
			writer = new BufferedWriter(new FileWriter(username + File.separator +  "saves" + File.separator + sessionName + File.separator + "log",true));
			writer.write(log);
			writer.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			try {
				if (writer != null) writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	/**
	 * checks if the game exists in files
	 * 
	 * @param username name of the user
	 * @param sessionName name of the session
	 * @return true if the game exists else false
	 */
	
	public static boolean doesGameExist(String username, String sessionName) {
		
		File folder = new File(username + File.separator + "saves");
        File file = new File(folder, sessionName);
		
		return file.exists();
	}
	/**
	 * Gets stats of the user from stats.txt then calculates required stats
	 * 
	 * @param username the name of the user
	 * @return returns stats type double
	 */
	
	public static double[] getStatsOfUser(String username) { // {wins,loses,winlossRatio,gamesPlayed,totalScore,averageScore}
		
		
		
		
		String winlossLine = "";
		String pointsLine = "";
		
		double wins = 0;
		double loses = 0;
		double totalScore = 0;
		double winlossRatio = 0;
		double gamesPlayed = 0;
		double averageScore = 0;
		double[] nullDouble = {0,0,-1,0,0,0};
		
		try {
			
			reader = new BufferedReader(new FileReader(username + File.separator + "stats.txt"));
			winlossLine = reader.readLine();
			pointsLine = reader.readLine();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
		}
		
		if (winlossLine.length() == 0 || pointsLine.length() == 0) return nullDouble;
		
		String[] winlossArray = winlossLine.split("∑");
		String[] pointsArray = pointsLine.split("∑");
		
		
		// count wins and loses
		
		for (String str : winlossArray) {
			
			if (str.equals("0")) loses++;
			else if (str.equals("1")) wins++;
		}
		
		
		// calculate number of games played
		
		File folder = new File(username + File.separator + "saves");
        File[] files = folder.listFiles();
        
        gamesPlayed = files.length;
		
		
		// calculate win/loss ratio
		
		try {
			
			winlossRatio = wins/loses;
			winlossRatio = Double.parseDouble(String.format("%." + 3 + "f", winlossRatio));
		}
		catch (ArithmeticException e) {
			
			winlossRatio = -1;
		}
		
		if(loses == 0) winlossRatio = -1;
		
		// calculate total score
		
		for (String str : pointsArray) {
			
			totalScore += Integer.parseInt(str);
		}
				
		
		// calculate average score
		
		try {
			
			averageScore = totalScore/gamesPlayed;
			averageScore = Double.parseDouble(String.format("%." + 3 + "f", averageScore));
		}
		catch (ArithmeticException e) {
			
			averageScore = 0;
		}
		
		double[] allStats = {wins,loses,winlossRatio,gamesPlayed,totalScore,averageScore};
		
		return allStats;
	}
	
	
	/**
	 * returns all game files that exist
	 * 
	 * @param username name of the user
	 * @return returns in type File[] all game files
	 */
	public static File[] getAllGameFiles(String username) {
		
		ArrayList<File> allGameFiles = new ArrayList<>();
		
		File userSaveFolder = new File(username + File.separator + "saves");
		
		File[] allFiles =  userSaveFolder.listFiles();
		
		if (allFiles != null) {
			
			for (File file : allFiles) {
				
				if (!file.getName().equals("stats.txt")) {
					
					allGameFiles.add(file);
				}
			}
		}
		
		System.out.println("all game files : " + allGameFiles);
		return allGameFiles.toArray(new File[0]);
	}
	
	/**
	 * Gets log file
	 * 
	 * @param gameFile the file where the log.txt is in
	 * @return log file inside
	 */
	public static File getLogFile(File gameFile) {
		
		File logFile = null;
		
		File[] game = gameFile.listFiles();
		if (game != null) {
			
			for (File insideGame : game) {
				
				if (insideGame.getName().equals("log")) {
					
					logFile = insideGame;
				}
			}
		}
		return logFile;
	}
		
	/**
	 * gets save file
	 * 
	 * @param gameFile file of game that has save.txt
	 * @return save file inside
	 */
	public static File getSaveFile(File gameFile) {
		
		File saveFile = null;
		
		File[] game = gameFile.listFiles();
		if (game != null) {
			
			for (File insideGame : game) {
				
				if (insideGame.getName().equals("save")) {
					
					saveFile = insideGame;
				}
			}
		}
		return saveFile;
	}
	
	/**
	 * saves the game
	 * 
	 * @param username name of the user
	 * @param characterList the characters that had played
	 * @param gameMaster the manager of game
	 * @param deckManager the manager of deck and card stuff
	 * @param gameSession the game session
	 */
	public static void saveGame(String username, ArrayList<GameCharacter> characterList, GameMaster gameMaster, DeckManager deckManager, GameSession gameSession) {
		
		String sessionName = gameMaster.getSessionName();		
		int botCount = characterList.size() - 1;				
		String playersHand = "";								
		String[] botsHands;										
		int index = gameMaster.getTurnIndex();					
		int gameDirection = gameSession.getReverseInt();		
		ArrayList<Card> deck = deckManager.getDeck();			
		ArrayList<Card> playedCards = Card.getPlayedCards();	
		String isUNO = "";										
		
		
		// Setting up variables
		
		ArrayList<String> botsHandsList = new ArrayList<>();
		for (int i = 0; i < characterList.size(); i++) {
			
			GameCharacter thisChar = characterList.get(i);
			
			isUNO += (thisChar.isUNO() ? "1" : "0");
			
			if (thisChar instanceof Player) {
				
				playersHand = thisChar.stringifyHand();
			}
			else {
				
				botsHandsList.add(thisChar.stringifyHand());
			}
		}
		
		botsHands = botsHandsList.toArray(new String[0]);
		
		
		
		String returnDeck = DeckManager.stringifyDeck(deck);
		
		String returnDiscard = DeckManager.stringifyDeck(playedCards);
		
		String handBot = "";
		
		
		for (String hand : botsHands) {
			
			handBot += hand;
			
			if (hand != botsHands[botsHands.length - 1]) handBot += "|";
					
			
		}
		
		String [] finalSave = {sessionName, botCount + "", playersHand, handBot, index + "", gameDirection + "", returnDeck, returnDiscard, isUNO};
		
		
		// Saving the game
		
		
		
		
		
		
		try {
			writer = new BufferedWriter(new FileWriter(username + File.separator +  "saves" + File.separator + sessionName + File.separator + "save",false));
			
			for (String text : finalSave) {
				
				if (text != finalSave[finalSave.length - 1])writer.write(text + "\n");
				else writer.write(text);
				
			}
			
			writer.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			try {
				if (writer != null) writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}