/**
 * 
 */
/**
 * 
 */
module UNO_Baran_Koçak {
	requires java.desktop;
}