package gameManagement;

import java.util.Comparator;

import javax.swing.JLabel;

public class LeaderBoardComparator implements Comparator<JLabel> {

	
	/**
	 * compares leaderboard components according to the points
	 * 
	 * @param o1 first label
	 * @param o2 second label
	 * 
	 * @return returns compare result
	 */
	@Override
	public int compare(JLabel o1, JLabel o2) {
		
		String text1 = o1.getText();
		String text2 = o2.getText();
		
		try {
            String[] separated1 = text1.split("> ");
            String[] separated2 = text2.split("> ");

            String[] shredded1 = separated1[1].split(" p");
            String[] shredded2 = separated2[1].split(" p");

            int num1 = Integer.parseInt(shredded1[0]);
            int num2 = Integer.parseInt(shredded2[0]);

            return Integer.compare(num2, num1);
            
        } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
            e.printStackTrace();
            return 0;
        }
	}

}
