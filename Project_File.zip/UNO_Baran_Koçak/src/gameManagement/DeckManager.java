package gameManagement;

import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;
import java.util.Collections;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import cards.Card;
import cards.DrawFourWildCard;
import cards.DrawTwoCard;
import cards.NumberCard;
import cards.ReverseCard;
import cards.SimpleWildCard;
import cards.SkipCard;
import gameCharacters.GameCharacter;
import gameCharacters.Player;
import thyGameRunner.GameMaster;



public class DeckManager {
	
	private ArrayList<Card> deck = new ArrayList<>();
	private static final Color unoRed = new Color(215, 38, 0);
	private static final Color unoBlue = new Color(9, 86, 191);
	private static final Color unoGreen = new Color(55, 151, 17);
	private static final Color unoYellow = new Color(165, 148, 5); //darker
	private static final Color[] COLORS = {unoRed, unoBlue, unoGreen, unoYellow};
	private GameMaster gameMaster;
	private ArrayList<JButton> discardedCardList = new ArrayList<>();
	
	public DeckManager(GameMaster gameMaster) {
		
		this.gameMaster = gameMaster;
	}
	
	
	// Deck generator
	/**
	 * generates new deck
	 * 
	 * @return deck
	 */
	public ArrayList<Card> generateDeck() {
		for(Color color:COLORS) {
			
			for(int num = 0; num < 10 ; num++) {
				
				NumberCard addd = new NumberCard(num, color);
				deck.add(addd);
				if(num != 0) {
					
					NumberCard adddd = new NumberCard(num, color);
					deck.add(adddd);
					
				}
			}
			for (int i = 0; i < 2; i++) {
				DrawTwoCard a1 = new DrawTwoCard(color);
				ReverseCard a2 = new ReverseCard(color);
				SkipCard a3 = new SkipCard(color);
				
				deck.add(a1);
				deck.add(a2);
				deck.add(a3);
			}
		}
		
		for (int i = 0; i < 4; i++) {
			
			deck.add(new SimpleWildCard());
			deck.add(new DrawFourWildCard());
		}
		
		return deck;
	}
	
	/**
	 * draws card
	 * 
	 * @param numberOfCards draws this many cards
	 * @param gameCharacter draws to this character
	 * @return drawnCards
	 */
	public Card[] drawCard(int numberOfCards, GameCharacter gameCharacter) {
		
		Card[] drawnCards = new Card[numberOfCards];
		
		for (int i = 0; i < numberOfCards; i++) {
			
			Card nextCard = deck.get(0);
			gameCharacter.addToHand(nextCard);
			drawnCards[i] = nextCard;
			deck.remove(0);
		}
		
		return drawnCards;
		
	}
	
	/**
	 * draws card
	 * 
	 * @param numberOfCards draws this many cards
	 * @param gameCharacter draws to this character
	 * @param playersHand in the game session where the cards will be displayed JPanel
	 * @param deckSizeText The size of the deck JLabel
	 * @return drawnCards
	 */
	public Card[] drawCard(int numberOfCards, GameCharacter gameCharacter, JPanel playersHand, JLabel deckSizeText) {   
		
		
		
		Card[] drawnCards = new Card[numberOfCards];
		
		for (int i = 0; i < numberOfCards; i++) {
			
			if (deck.size() == 0) {
				
				reShuffleDeck();
			}
			
			Card nextCard = deck.get(0);
			gameCharacter.addToHand(nextCard);
			drawnCards[i] = nextCard;
			deck.remove(0);
			
			
		}
		/************** DIFFERENCE ****************/
		if (gameCharacter.getClass().getSimpleName().equals("Player")) {
			
			gameCharacter.setUNO(false);
			
			
			for (Card drawnCard : drawnCards) {
				
				
				JLabel newCard = drawnCard.getLabelledCard();
				
				
				playersHand.add(newCard);
				playersHand.revalidate();
				playersHand.repaint();

			}
				
		}
		else if (gameCharacter.getClass().getSimpleName().equals("Bot")){
			
//			gameCharacter.getMyBotPanel().setHandSize(gameCharacter.getCardsInHand().size());
			
		}
		
		int deckSize = deck.size();
		deckSizeText.setText(Integer.toString(deckSize));
		
		return drawnCards;
		
	}
	
	/**
	 * makes it so that at the first round there is a card on top
	 * 
	 * @param deckSizeText JLabel
	 * @return Card discarded
	 */
	public Card discardFirstCardOfDeck(JLabel deckSizeText) {
		
		Card card;
		
		
		
		card = deck.get(0);
		deck.remove(0);
		JLabel label = new JLabel("-----FIRST CARD OF THE GAME----");
		Font italicFont = new Font(label.getFont().getName(), Font.ITALIC, label.getFont().getSize());
		label.setFont(italicFont);
		label.setForeground(Color.gray);
		gameMaster.getGameSession().getPlayField().add(label);
		gameMaster.appendLog(label.getText());
		
		gameMaster.getGameSession().getPlayField().add(card.getLabelledCard());
		card.getLabelledCard().setText("--> " + card.getLabelledCard().getText());
		card.setPlayed(true);
		gameMaster.getGameSession().getPlayField().revalidate();
		gameMaster.getGameSession().getPlayField().repaint();
		gameMaster.appendLog(card.getLabelledCard().getText());
		
		Card.getPlayedCards().add(card);
//		System.out.println(Card.getPlayedCards());
		
		int deckSize = deck.size();
		deckSizeText.setText(Integer.toString(deckSize));
		
		return card;
	}
	
	/**
	 * when the draw pile empties this method makes a new deck from discard pile
	 * 
	 */
	public void reShuffleDeck() {
		
		
		ArrayList<Card> playedCards = Card.getPlayedCards();
		System.out.println(playedCards);
		
		
		ArrayList<Card> everythingButTopCard = new ArrayList<>(playedCards.subList(0, playedCards.size() - 1));
		ArrayList<Card> newDeck = new ArrayList<>();
		
		for (int i = 0; i < everythingButTopCard.size(); i++) {
			
			Card nextCard = everythingButTopCard.get(i);
			
			if (nextCard instanceof NumberCard) {
				
			    NumberCard newCard = new NumberCard(nextCard.getNum(), nextCard.getColor());
			    newCard.setGameMaster(gameMaster);
			    newCard.setPlayField(gameMaster.getGameSession().getPlayField());
			    newCard.setPlayer((Player) gameMaster.getCharacterList().get(0));
			    newDeck.add(newCard);
			    
			} else if (nextCard instanceof DrawTwoCard) {
			    DrawTwoCard newCard = new DrawTwoCard(nextCard.getColor());
			    newCard.setGameMaster(gameMaster);
			    newCard.setPlayField(gameMaster.getGameSession().getPlayField());
			    newCard.setPlayer((Player) gameMaster.getCharacterList().get(0));
			    newDeck.add(newCard);
			    
			} else if (nextCard instanceof SkipCard) {
			    SkipCard newCard = new SkipCard(nextCard.getColor());
			    newCard.setGameMaster(gameMaster);
			    newCard.setPlayField(gameMaster.getGameSession().getPlayField());
			    newCard.setPlayer((Player) gameMaster.getCharacterList().get(0));
			    newDeck.add(newCard);
			    
			} else if (nextCard instanceof ReverseCard) {
			    ReverseCard newCard = new ReverseCard(nextCard.getColor());
			    newCard.setGameMaster(gameMaster);
			    newCard.setPlayField(gameMaster.getGameSession().getPlayField());
			    newCard.setPlayer((Player) gameMaster.getCharacterList().get(0));
			    newDeck.add(newCard);
			    
			} else if (nextCard instanceof SimpleWildCard) {
			    SimpleWildCard newCard = new SimpleWildCard();
			    newCard.setGameMaster(gameMaster);
			    newCard.setPlayField(gameMaster.getGameSession().getPlayField());
			    newCard.setPlayer((Player) gameMaster.getCharacterList().get(0));
			    newDeck.add(newCard);
			    
			} else if (nextCard instanceof DrawFourWildCard) {
			    DrawFourWildCard newCard = new DrawFourWildCard();
			    newCard.setGameMaster(gameMaster);
			    newCard.setPlayField(gameMaster.getGameSession().getPlayField());
			    newCard.setPlayer((Player) gameMaster.getCharacterList().get(0));
			    newDeck.add(newCard);
			    
			}

			
		}

		
		Collections.shuffle(newDeck);
		
		System.out.println(playedCards.size() + "<-------");
		
		playedCards.clear();
		
		deck = newDeck;
		gameMaster.setDeck(newDeck);
		
		JLabel explainor = new JLabel();
		explainor.setText("deck out of cards reshuffling" + "(" + newDeck.size() + ")...");
		explainor.setForeground(new Color(0x07e7f72));
		Font italicFont = new Font(explainor.getFont().getName(), Font.ITALIC, explainor.getFont().getSize());
		explainor.setFont(italicFont);
		
		gameMaster.getGameSession().getPlayField().add(explainor);
		gameMaster.appendLog(explainor.getText());
	}
	
	/**
	 * to save it makes it a string
	 * 
	 * @param deck the deck
	 * @return the stringified version of deck
	 */
	public static String stringifyDeck(ArrayList<Card> deck) {
		
		String cardString = "";
		
		for (int i = 0; i < deck.size(); i++) {
			
			Card card = deck.get(i);
			
			
			if (card.getColorString().equals("blue")) cardString += "B";
			else if (card.getColorString().equals("red")) cardString += "R";
			else if (card.getColorString().equals("yellow")) cardString += "Y";
			else if (card.getColorString().equals("green")) cardString += "G";
			else cardString += "W";
			
			if (card instanceof NumberCard) cardString += card.getNum();
			else if (card instanceof ReverseCard) cardString += "G";		// reverseCard = "G"
			else if (card instanceof SkipCard) cardString += "S";			// skipCard = "S"
			else if (card instanceof DrawTwoCard) cardString += "T";		// drawTwo  = "T"
			else if (card instanceof SimpleWildCard) cardString += "J";		// simpleWild = "J"
			else if (card instanceof DrawFourWildCard) cardString += "F";	// drawFour = "F"
			
			if (i != deck.size() - 1) cardString += "∑";
			
			
		}
		
		
		
		return cardString;
		
	}
	
	
	
	
	
	

	
	
	
	public ArrayList<Card> getDeck() {
		return deck;
	}





	public void setDeck(ArrayList<Card> deck) {
		this.deck = deck;
	}





	public static Color[] getColors() {
		return COLORS;
	}


	public GameMaster getGameMaster() {
		return gameMaster;
	}


	public void setGameMaster(GameMaster gameMaster) {
		this.gameMaster = gameMaster;
	}


	public ArrayList<JButton> getDiscardedCardList() {
		return discardedCardList;
	}


	public void setDiscardedCardList(ArrayList<JButton> discardedCardList) {
		this.discardedCardList = discardedCardList;
	}


	public static Color getUnored() {
		return unoRed;
	}


	public static Color getUnoblue() {
		return unoBlue;
	}


	public static Color getUnogreen() {
		return unoGreen;
	}


	public static Color getUnoyellow() {
		return unoYellow;
	}


	
	
	

	
	
	
	
	
	
	
	
	
	
	
}


