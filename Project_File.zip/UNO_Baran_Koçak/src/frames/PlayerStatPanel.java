package frames;

import javax.swing.JPanel;
import javax.swing.border.LineBorder;

import accountManagement.AccountWizard;

import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.UIManager;
import javax.swing.SwingConstants;




public class PlayerStatPanel extends JPanel {

//	private static final Color r0 = new Color(0x0f7cac3);
//	private static final Color r1 = new Color(0x0E4B1AB);
//	private static final Color r2 = new Color(0x0E39695);
//	private static final Color r3 = new Color(0x0DF7373);
//	private static final Color r4 = new Color(0x0DA5552);
//	private static final Color r5 = new Color(0x0CC444B);
	private static final Color r0 = null;
	private static final Color r1 = null;
	private static final Color r2 = null;
	private static final Color r3 = null;
	private static final Color r4 = null;
	private static final Color r5 = null;
	private double[] stats;
	private String username;
	
	
	
	private static final long serialVersionUID = 1L;

	
	/**
	 * displays the user's stats
	 * 
	 * @param username name of the user
	 */
	public PlayerStatPanel(String username) {
		this.username = username;
																	// {wins,loses,winlossRatio,gamesPlayed,totalScore,averageScore}
		updateStats();
		
		setBorder(new LineBorder(null));
		setLayout(new GridLayout(7, 0));
		
		JPanel usernameText = new JPanel();
		add(usernameText);
		usernameText.setLayout(new GridLayout(0, 1, 0, 0));
		
		JLabel lblNewLabel = new JLabel(username + "'s STATS");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		usernameText.add(lblNewLabel);
		
		JPanel winPanel = new JPanel();
		winPanel.setBorder(new LineBorder(new Color(201, 201, 201)));
		add(winPanel);
		winPanel.setLayout(new GridLayout(1, 0, 0, 0));
		winPanel.setBackground(r1);
		
		JLabel lblNewLabel_1_2 = new JLabel("WINS");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setForeground(Color.BLACK);
		lblNewLabel_1_2.setBackground(UIManager.getColor("Button.background"));
		winPanel.add(lblNewLabel_1_2);
		
		JLabel winLabel = new JLabel((int)stats[0] + "");
		winLabel.setHorizontalAlignment(SwingConstants.CENTER);
		winPanel.add(winLabel);
		
		JPanel lossPanel = new JPanel();
		lossPanel.setBorder(new LineBorder(new Color(201, 201, 201)));
		add(lossPanel);
		lossPanel.setLayout(new GridLayout(1, 0, 0, 0));
		lossPanel.setBackground(r2);
		
		JLabel lblNewLabel_1 = new JLabel("LOSSES");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lossPanel.add(lblNewLabel_1);
		lblNewLabel_1.setForeground(Color.BLACK);
		lblNewLabel_1.setBackground(UIManager.getColor("Button.background"));
		
		JLabel lossLabel = new JLabel((int)stats[1] + "");
		lossLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lossPanel.add(lossLabel);
		
		JPanel ratioPanel = new JPanel();
		ratioPanel.setBorder(new LineBorder(new Color(201, 201, 201)));
		add(ratioPanel);
		ratioPanel.setLayout(new GridLayout(1, 0, 0, 0));
		ratioPanel.setBackground(r3);
		
		JLabel lblNewLabel_1_1 = new JLabel("WIN/LOSS RATIO");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setForeground(Color.BLACK);
		lblNewLabel_1_1.setBackground(UIManager.getColor("Button.background"));
		ratioPanel.add(lblNewLabel_1_1);
		
		JLabel ratioLabel = new JLabel(stats[2] + "");
		ratioLabel.setHorizontalAlignment(SwingConstants.CENTER);
		ratioPanel.add(ratioLabel);
		
		JPanel numberOfGamesPanel = new JPanel();
		numberOfGamesPanel.setBorder(new LineBorder(new Color(201, 201, 201)));
		add(numberOfGamesPanel);
		numberOfGamesPanel.setLayout(new GridLayout(1, 0, 0, 0));
		numberOfGamesPanel.setBackground(r2);
		
		JLabel lblNewLabel_1_3 = new JLabel("NUMBER OF GAMES PLAYED");
		lblNewLabel_1_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_3.setForeground(Color.BLACK);
		lblNewLabel_1_3.setBackground(UIManager.getColor("Button.background"));
		numberOfGamesPanel.add(lblNewLabel_1_3);
		
		JLabel numberOfGamesLabel = new JLabel((int)stats[3] + "");
		numberOfGamesLabel.setHorizontalAlignment(SwingConstants.CENTER);
		numberOfGamesPanel.add(numberOfGamesLabel);
		
		JPanel totalScorePanel = new JPanel();
		totalScorePanel.setBorder(new LineBorder(new Color(201, 201, 201)));
		add(totalScorePanel);
		totalScorePanel.setLayout(new GridLayout(1, 0, 0, 0));
		totalScorePanel.setBackground(r1);
		
		JLabel lblNewLabel_1_4 = new JLabel("TOTAL SCORE");
		lblNewLabel_1_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_4.setForeground(Color.BLACK);
		lblNewLabel_1_4.setBackground(UIManager.getColor("Button.background"));
		totalScorePanel.add(lblNewLabel_1_4);
		
		JLabel totalScoreLabel = new JLabel((int)stats[4] + "");
		totalScoreLabel.setHorizontalAlignment(SwingConstants.CENTER);
		totalScorePanel.add(totalScoreLabel);
		
		JPanel averageScorePanel = new JPanel();
		averageScorePanel.setBackground(new Color(250, 246, 238));
		averageScorePanel.setBorder(new LineBorder(new Color(201, 201, 201)));
		add(averageScorePanel);
		averageScorePanel.setLayout(new GridLayout(1, 0, 0, 0));
		averageScorePanel.setBackground(r0);
		
		JLabel lblNewLabel_1_4_1 = new JLabel("AVERAGE SCORE");
		lblNewLabel_1_4_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_4_1.setForeground(Color.BLACK);
		lblNewLabel_1_4_1.setBackground(UIManager.getColor("Button.background"));
		averageScorePanel.add(lblNewLabel_1_4_1);
		
		JLabel averageScoreLabel = new JLabel(stats[5] + "");
		averageScoreLabel.setHorizontalAlignment(SwingConstants.CENTER);
		averageScorePanel.add(averageScoreLabel);

	}
	
	/**
	 * updates stats
	 * 
	 */
	public void updateStats() {
		
		stats = AccountWizard.getStatsOfUser(username);
		revalidate();
		repaint();
	}

}
