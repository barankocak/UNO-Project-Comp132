package frames;



import javax.swing.JPanel;

import gameCharacters.Bot;
import gameCharacters.GameCharacter;
import javax.swing.JLabel;
import java.awt.GridLayout;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import java.awt.Color;

public class BotStatusPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private int handSize;
	private JLabel botHandSize;
	private Bot bot;
	private static int i = 0;

	/**
	 * creates a bot status panel that shows bots name and cards remaining
	 * 
	 * 
	 * @param bot which bot is going to be displayed
	 */
	public BotStatusPanel(GameCharacter bot) {
		
		
		this.bot = (Bot) bot;
		handSize = bot.getCardsInHand().size();
//		System.out.println(bot.getCardsInHand().size());
		
		setBorder(new LineBorder(new Color(0, 0, 0)));
		setLayout(new GridLayout(0, 2, 0, 0));
		
		
		
		JLabel botsName = new JLabel("<name of the bot>");
		add(botsName);
		
		botsName.setText(bot.getName());
		
		botHandSize = new JLabel("Cards left: " + handSize);
		botHandSize.setHorizontalAlignment(SwingConstants.TRAILING);
		add(botHandSize);
		
		updateHandSizeText();
		
		bot.setMyBotPanel(this);
	}
	
	/**
	 * updates JLabel handsize to be accurate
	 * 
	 */
	public void updateHandSizeText() {
		
		handSize = bot.getCardsInHand().size();
		i++;
		botHandSize.setText("Cards remaining " + handSize);
		
		
		botHandSize.revalidate();
		botHandSize.repaint();
//		System.out.println("iiiii:" + i);
	}
	
	public void updateBackground(Color color) {
		
		setBackground(color);
	}


	public int getHandSize() {
		return handSize;
	}


	public void setHandSize(int handSize) {
		this.handSize = handSize;
	}


	public JLabel getBotHandSize() {
		return botHandSize;
	}


	public void setBotHandSize(JLabel botHandSize) {
		this.botHandSize = botHandSize;
	}


	public Bot getBot() {
		return bot;
	}


	public void setBot(Bot bot) {
		this.bot = bot;
	}

	
	
	
}
