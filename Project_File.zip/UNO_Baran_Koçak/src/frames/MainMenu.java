package frames;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;

import javax.swing.border.LineBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import accountManagement.AccountWizard;
import cards.Card;
import cards.DrawFourWildCard;
import cards.DrawTwoCard;
import cards.NumberCard;
import cards.ReverseCard;
import cards.SimpleWildCard;
import cards.SkipCard;
import gameCharacters.GameCharacter;
import gameCharacters.Player;
import gameManagement.DeckManager;
import gameManagement.LeaderBoardComparator;
import thyGameRunner.GameMaster;

import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.BoxLayout;
import java.awt.GridLayout;

public class MainMenu extends JFrame {

	private JPanel contentPane;
	private JTextField gameNameText;
	private JTextField numOfPlayersText;
	private String username;
	private String sessionName;
	private JPanel leaderBoardPanel;
	private JPanel displayStatusPanel;
	private GameMaster newGame;
	private MainMenu me;
	private JPanel savedGames;
	private BufferedReader reader;
	
	// saved game stuff
	
	private String savedSessionName;
	private String botCount;
	private String playersHand;
	private String handBot;
	private String index;
	private String gameDirection;
	private String deck;
	private String discard;
	private String isUNO;
	
	/**
	 * in the middle create new game top right leaderboard top left lead games :) bottom right logout and refresh
	 * 
	 * @param username name of the user
	 */
	public MainMenu(String username) {
		
		this.username = username;
		this.me = this;
		
		
		
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (screenSize.width - 1000) / 2;
		int y = (screenSize.height - 700) / 2;
		setBounds(x, y, 1000, 700);
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		displayStatusPanel = new JPanel();
		displayStatusPanel.setBounds(320, 27, 429, 186);
		contentPane.add(displayStatusPanel);
		
		JPanel leaderBoardPanelBorder = new JPanel();
		leaderBoardPanelBorder.setBorder(new LineBorder(new Color(0, 0, 0)));
		leaderBoardPanelBorder.setBounds(761, 6, 233, 401);
		leaderBoardPanelBorder.setBackground(new Color(0x0cfb472));
		contentPane.add(leaderBoardPanelBorder);
		leaderBoardPanelBorder.setLayout(null);
		
		leaderBoardPanel = new JPanel();
		leaderBoardPanel.setBounds(6, 38, 221, 357);
		leaderBoardPanelBorder.add(leaderBoardPanel);
		leaderBoardPanel.setBackground(new Color(207, 180, 114));
		leaderBoardPanel.setBorder(null);
		leaderBoardPanel.setLayout(new GridLayout(15, 1, 0, 0));
		
		JLabel leaderBoardText = new JLabel("LEADERBOARD");
		leaderBoardText.setBounds(51, 5, 131, 21);
		leaderBoardPanelBorder.add(leaderBoardText);
		leaderBoardText.setFont(new Font("Lucida Grande", Font.BOLD, 17));
		leaderBoardText.setForeground(new Color(245, 251, 255));
		leaderBoardText.setBackground(new Color(197, 225, 71));
		leaderBoardText.setHorizontalAlignment(SwingConstants.CENTER);

		
		
		addPlayersToLeaderboard();
		
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_1.setBounds(6, 6, 233, 230);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel savedGamesBorder = new JLabel("SAVED GAMES");
		savedGamesBorder.setFont(new Font("Lucida Grande", Font.ITALIC, 13));
		savedGamesBorder.setHorizontalAlignment(SwingConstants.CENTER);
		savedGamesBorder.setBounds(6, 6, 221, 16);
		panel_1.add(savedGamesBorder);
		
		savedGames = new JPanel();
		savedGames.setBorder(new LineBorder(new Color(215, 215, 215)));
		savedGames.setBounds(6, 34, 221, 190);
		panel_1.add(savedGames);
		savedGames.setLayout(new BoxLayout(savedGames, BoxLayout.Y_AXIS));

		
		addSavedGames();
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setLayout(null);
		panel_1_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_1_1.setBounds(378, 253, 233, 230);
		contentPane.add(panel_1_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("START A NEW GAME");
		lblNewLabel_1_1.setFont(new Font("Lucida Grande", Font.ITALIC, 13));
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setBounds(6, 6, 221, 16);
		panel_1_1.add(lblNewLabel_1_1);
		
		gameNameText = new JTextField();
		gameNameText.setHorizontalAlignment(SwingConstants.CENTER);
		gameNameText.setBounds(49, 72, 136, 26);
		panel_1_1.add(gameNameText);
		gameNameText.setColumns(10);
		
		
		JLabel lblNewLabel_2 = new JLabel("SESSION NAME");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(6, 46, 221, 16);
		panel_1_1.add(lblNewLabel_2);
		
		numOfPlayersText = new JTextField();
		numOfPlayersText.setHorizontalAlignment(SwingConstants.CENTER);
		numOfPlayersText.setText("between 2 - 10");
		numOfPlayersText.setColumns(10);
		numOfPlayersText.setBounds(49, 157, 136, 26);
	
		numOfPlayersText.getDocument().addDocumentListener(new DocumentListener() {
			
			@Override
			public void insertUpdate(DocumentEvent e) {
				String insertedText = numOfPlayersText.getText().substring(e.getOffset(), e.getOffset() + e.getLength());
				
				if (!isInteger(insertedText)) {
                    // Remove non-integer characters
                    SwingUtilities.invokeLater(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                numOfPlayersText.getDocument().remove(e.getOffset(), e.getLength());
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                    });
                }
			}

			@Override
			public void removeUpdate(DocumentEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void changedUpdate(DocumentEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		
		numOfPlayersText.addFocusListener(new FocusListener() {
			
            public void focusGained(FocusEvent e) {
            	if (numOfPlayersText.getText().equals("between 2 - 10")) numOfPlayersText.setText("");
            }

            public void focusLost(FocusEvent e) {
                if (numOfPlayersText.getText().isEmpty()) {
                    numOfPlayersText.setText("between 2 - 10");
                }
            }
        });
		panel_1_1.add(numOfPlayersText);
		
		JLabel lblNewLabel_2_1 = new JLabel("NUMBER OF PLAYERS");
		lblNewLabel_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_1.setBounds(6, 129, 221, 16);
		panel_1_1.add(lblNewLabel_2_1);
		
		JButton logOutButton = new JButton("Logout");
		logOutButton.setForeground(new Color(246, 2, 0));
		logOutButton.setBackground(new Color(255, 203, 121));
		logOutButton.setBounds(877, 637, 117, 29);
		logOutButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == logOutButton) {
					
					LoginScreen loginScreen = new LoginScreen();
					loginScreen.setVisible(true);
					MainMenu.this.dispose();
					
				}
				
			}
		});
		
		JButton createNewGameButton = new JButton("CREATE NEW GAME");
		createNewGameButton.setBounds(6, 195, 221, 29);
		panel_1_1.add(createNewGameButton);
		
		JLabel sessionNameWarningLabel = new JLabel("Session already exsists");
		sessionNameWarningLabel.setForeground(new Color(248, 97, 54));
		sessionNameWarningLabel.setHorizontalAlignment(SwingConstants.CENTER);
		sessionNameWarningLabel.setBounds(6, 101, 221, 16);
		sessionNameWarningLabel.setVisible(false);
		panel_1_1.add(sessionNameWarningLabel);
		createNewGameButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if (e.getSource() == createNewGameButton) {
					// if empty generates random name
					if (!AccountWizard.doesGameExist(username, gameNameText.getText()) || gameNameText.getText().length() == 0) {
						int num;
						Player player = new Player(username);
						if (numOfPlayersText.getText().equals("between 2 - 10") || numOfPlayersText.getText().equals("")) num = 4;
						else num = Integer.parseInt(numOfPlayersText.getText());
						if (num < 2) num = 1;
						else if (num > 10) num = 9;
						else num -= 1;
						if (gameNameText.getText().length() == 0) {
							
							int upperBound = 100000; // lowerBound WHEN COME BACK RENAME THESE
							int lowerBound = 999999; // upperBound
							
							Random random = new Random();
					        int randomInt = random.nextInt(lowerBound - upperBound + 1) + upperBound;
					        
					        while (AccountWizard.doesGameExist(username, randomInt + "")) randomInt = random.nextInt(lowerBound - upperBound + 1) + upperBound;
					        
					        gameNameText.setText(randomInt + "");
							
						}
						newGame = new GameMaster(player, num, gameNameText.getText());   // GAMEMASTER CONTRUCTION AS WELL AS PLAYER
						newGame.setDisposalMainMenu(MainMenu.this);
						player.setGameMaster(newGame);
						newGame.runGame();
						
					}
					else {
						
						sessionNameWarningLabel.setVisible(true);
					}
					

				}
				
			}
		});
		
		
		contentPane.add(logOutButton);
		
		JLabel lblNewLabel_3 = new JLabel("If you insert a number that is not between 2 and 10 the number inserted will be rounded up or down according to the interval");
		lblNewLabel_3.setForeground(new Color(126, 127, 114));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(6, 495, 988, 21);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_3_1 = new JLabel("If you leave the session name blank, a random set of numbers will be assigned");
		lblNewLabel_3_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_1.setForeground(new Color(126, 127, 114));
		lblNewLabel_3_1.setBounds(6, 517, 988, 21);
		contentPane.add(lblNewLabel_3_1);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("Default number is 4");
		lblNewLabel_3_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_1_1.setForeground(new Color(126, 127, 114));
		lblNewLabel_3_1_1.setBounds(6, 539, 988, 21);
		contentPane.add(lblNewLabel_3_1_1);
		
		JLabel welcomerLabel = new JLabel("welcome");
		welcomerLabel.setHorizontalAlignment(SwingConstants.CENTER);
		welcomerLabel.setForeground(new Color(126, 127, 114));
		welcomerLabel.setBounds(378, 225, 233, 21);
		welcomerLabel.setText("Welcome " + username + "!");
		contentPane.add(welcomerLabel);
		
		JLabel lblNewLabel = new JLabel("Click on to the player name to see logs ");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(320, 6, 429, 16);
		contentPane.add(lblNewLabel);
		lblNewLabel.setForeground(new Color(126, 127, 114));
		
		JButton refreshButton = new JButton("Refresh");
		refreshButton.setBounds(761, 637, 117, 29);
		contentPane.add(refreshButton);
		
		reorderLB(); // REORDER LEADER BOARD
		
		JLabel lblClickOnA = new JLabel("Click on a saved game to play");
		lblClickOnA.setHorizontalAlignment(SwingConstants.CENTER);
		lblClickOnA.setForeground(new Color(126, 127, 114));
		lblClickOnA.setBounds(6, 253, 233, 16);
		contentPane.add(lblClickOnA);
		refreshButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {

				GameMaster.refreshMainMenu(me,username);
				
				
			}
		});
		
		
		
		
		
		
		
	}
	
	/**
	 * fixes the ordering of the leader board
	 * 
	 */
	public void reorderLB() {
		
		Component[] comps = leaderBoardPanel.getComponents();
		JLabel[] labels = new JLabel[comps.length];
		
		for (int i = 0; i < comps.length; i++) {
	        labels[i] = (JLabel) comps[i];
	    }
		
		
		Arrays.sort(labels, new LeaderBoardComparator());
		
		leaderBoardPanel.removeAll();
		
		for (JLabel label : labels) {
	        leaderBoardPanel.add(label);
	    }
		leaderBoardPanel.revalidate();
	    leaderBoardPanel.repaint();
	}
	
	
	/**
	 * checks if integer
	 * 
	 * @param s the checked string
	 * @return true if integer
	 */
	private boolean isInteger(String s) {
        try {
            Integer.parseInt(s);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
	/**
	 * adds players to leader board
	 * 
	 */
	private void addPlayersToLeaderboard() {
		
		ArrayList<String> listOfUsernames = new AccountWizard().getUsernames();
		for (String currentUsername : listOfUsernames) {
			
			
			JLabel usernameLabel = new JLabel();
			
			usernameLabel.setText(currentUsername + " --> " + (int) AccountWizard.getStatsOfUser(currentUsername)[4] + " points");
			
			PlayerStatPanel statPanel = new PlayerStatPanel(currentUsername);
			

			if (currentUsername.equals(username)) {
				usernameLabel.setForeground(Color.white);
			}
			
			Color normalColor = usernameLabel.getForeground();
			
			
			usernameLabel.addMouseListener(new MouseAdapter() {
				
				@Override
				public void  mousePressed(MouseEvent e) {
					
					DisplayLogScreen logScreen = new DisplayLogScreen(currentUsername);
				}
				
				
				@Override
				public void mouseEntered(MouseEvent e) {
					
					statPanel.updateStats();
					usernameLabel.setForeground(new Color(0x0DF7373));
					
					displayStatusPanel.add(statPanel);
					statPanel.setVisible(true);
					statPanel.revalidate();
					statPanel.repaint();
					
				}
				
				
				@Override
				public void mouseExited(MouseEvent e) {
					
					usernameLabel.setForeground(normalColor);
					
					
					statPanel.setVisible(false);
					displayStatusPanel.remove(statPanel);
					statPanel.revalidate();
					statPanel.repaint();
				}
				
			});
			
			
			
			
			leaderBoardPanel.add(usernameLabel);
			
			
		}
		
	}

	/**
	 * adds saved games to the JPanel
	 * 
	 */
	private void addSavedGames() {
		
		File[] gameFiles = AccountWizard.getAllGameFiles(username);
		
		for (int i = 0; i < gameFiles.length; i++) {
			

			File gameFile = gameFiles[i];
			File saveFile = AccountWizard.getSaveFile(gameFile);
			if (saveFile == null) continue;
			System.out.println("-->" + saveFile);
			
			JLabel fileNameLabel = new JLabel();
			fileNameLabel.setText(gameFile.getName());
			Color normalColor = fileNameLabel.getForeground();
			
			fileNameLabel.addMouseListener(new MouseAdapter() {
				
				@Override
				public void  mousePressed(MouseEvent e) {
					
					try {    // {sessionName, botCount + "", playersHand, handBot, index + "", gameDirection + "", returnDeck, returnDiscard, isUNO};
						
						reader = new BufferedReader(new FileReader(saveFile));
						
						sessionName  = reader.readLine();
						botCount  = reader.readLine();
						playersHand  = reader.readLine();
						handBot  = reader.readLine();
						index  = reader.readLine();
						gameDirection  = reader.readLine();
						deck  = reader.readLine();
						discard  = reader.readLine();
						isUNO  = reader.readLine();
						
//						TestGame2
//						1
//						R6∑RG
//						R4∑BT∑B4∑YT∑R5∑Y5∑R1
//						0
//						-1
//						Y7∑Y1∑Y5∑G1∑B1∑G2∑WJ∑Y2∑RT∑B1∑G1∑Y3∑WJ∑B8∑R8∑WF∑Y3∑R1∑B0∑RS∑YS∑Y4∑R0∑G4∑Y7∑Y2∑R3∑B7∑BG∑B6∑R2∑WJ∑B3∑R9∑Y8∑G5∑Y0∑R2∑BS∑G7∑Y1∑YG∑YG∑G3∑G5∑WF∑BG∑BT∑GT∑GG∑GG∑R3∑G6∑R7∑GS∑R6
//						B9∑B5∑B5∑RJ∑YF∑Y9∑Y6∑YS∑RS∑RT∑R9∑GF∑G9∑G6∑G4∑G8∑B8∑B2∑B2∑BS∑GS∑G8∑R8∑R5∑R7∑RG∑R4∑B4∑Y4∑YT∑Y9∑Y8∑Y6∑B6∑B7∑B9∑B3∑G3∑G0∑GT∑G7∑G9∑G2
//						00
						
					} catch (FileNotFoundException e1) {
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} finally {
						
						try {
							reader.close();
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					}
					
					
					
//					instantiateSavedGame();
					
					
				}
				
				
				@Override
				public void mouseEntered(MouseEvent e) {
					
					
					fileNameLabel.setForeground(new Color(0x0DF7373));
					
				}
				
				
				@Override
				public void mouseExited(MouseEvent e) {
					
					
					fileNameLabel.setForeground(normalColor);
					
					
				}
				
				
				
			});
			
			fileNameLabel.setHorizontalAlignment(SwingConstants.CENTER);
			fileNameLabel.setVerticalAlignment(SwingConstants.CENTER);
			if (saveFile != null) savedGames.add(fileNameLabel);
			fileNameLabel.revalidate();
			fileNameLabel.repaint();
			savedGames.revalidate();
			savedGames.repaint();
			
		}
		
		
	}
	/**
	 * 
	 * instantiates the saved game :)
	 * 
	 */
	private void instantiateSavedGame() {
		
//		sessionName  = reader.readLine(); +
//		botCount  = reader.readLine(); +
//		playersHand  = reader.readLine(); +
//		handBot  = reader.readLine(); +
//		index  = reader.readLine(); +
//		gameDirection  = reader.readLine(); +
//		deck  = reader.readLine(); +
//		discard  = reader.readLine(); +
//		isUNO  = reader.readLine(); +
//		
//		TestGame2
//		1
//		R6∑RG
//		R4∑BT∑B4∑YT∑R5∑Y5∑R1
//		0
//		-1
//		Y7∑Y1∑Y5∑G1∑B1∑G2∑WJ∑Y2∑RT∑B1∑G1∑Y3∑WJ∑B8∑R8∑WF∑Y3∑R1∑B0∑RS∑YS∑Y4∑R0∑G4∑Y7∑Y2∑R3∑B7∑BG∑B6∑R2∑WJ∑B3∑R9∑Y8∑G5∑Y0∑R2∑BS∑G7∑Y1∑YG∑YG∑G3∑G5∑WF∑BG∑BT∑GT∑GG∑GG∑R3∑G6∑R7∑GS∑R6
//		B9∑B5∑B5∑RJ∑YF∑Y9∑Y6∑YS∑RS∑RT∑R9∑GF∑G9∑G6∑G4∑G8∑B8∑B2∑B2∑BS∑GS∑G8∑R8∑R5∑R7∑RG∑R4∑B4∑Y4∑YT∑Y9∑Y8∑Y6∑B6∑B7∑B9∑B3∑G3∑G0∑GT∑G7∑G9∑G2
//		00
		
		Player gamer = new Player(username);
		
		
		GameMaster newGameMaster = new GameMaster(gamer, Integer.parseInt(botCount), savedSessionName);
		
		
		
		
		newGameMaster.setDisposalMainMenu(me);
		
		GameSession savedSession = new GameSession(newGameMaster, savedSessionName);
		
		
		
		newGameMaster.setGameSession(savedSession);
		newGameMaster.getDeckManager().setGameMaster(newGameMaster);
		
		newGameMaster.setTurnIndex(Integer.parseInt(index));
		
		ArrayList<Card> savedDeck = stringToDeck(deck);
		ArrayList<Card> savedDiscard = stringToDeck(discard);
		ArrayList<Card> savedPlayersHand = stringToDeck(playersHand);
		
		newGameMaster.setDeck(savedDeck);
		Card.setPlayedCards(savedDiscard);
		
		newGameMaster.getCharacterList().get(0).setCardsInHand(savedPlayersHand);
		
		ArrayList<Card>[] botHands = getBotsStartingHand(handBot);
		
		for (int i = 1; i < newGameMaster.getCharacterList().size(); i++) {
			
			GameCharacter bot = newGameMaster.getCharacterList().get(i);
			
			bot.setCardsInHand(botHands[i - 1]);
		}
		
		for (int i = 0; i < newGameMaster.getCharacterList().size(); i++) {
			
			GameCharacter character = newGameMaster.getCharacterList().get(i);
			
			char isUno = isUNO.charAt(i);
			
			if (isUno == '0') character.setUNO(false);
			else if (isUno == '1') character.setUNO(true);
		}
		
		savedSession.setReverseInt(Integer.parseInt(gameDirection));
		
		newGameMaster.runSavedGame(savedDiscard.get(savedDiscard.size() - 1));
		
	}
	
	/**
	 * converts deck to string
	 * 
	 * 
	 * @param next the string
	 * @return card list
	 */
	private ArrayList<Card> stringToDeck(String next) {
		
		String[] deckArray = next.split("∑");
		
		ArrayList<Card> newDeck = new ArrayList<>();
		
		for (String card : deckArray) {
			
			char first = card.charAt(0);
			char second = card.charAt(1);
			
			Color color = null;
			
			if (first == 'B') color = DeckManager.getUnoblue();
			else if (first == 'R') color = DeckManager.getUnored();
			else if (first == 'Y') color = DeckManager.getUnoyellow();
			else if (first == 'G') color = DeckManager.getUnogreen();
			
			if (second == 'G') newDeck.add(new ReverseCard(color));
			else if (second == 'S') newDeck.add(new SkipCard(color));
			else if (second == 'T') newDeck.add(new DrawTwoCard(color));
			else if (second == 'J') newDeck.add(new SimpleWildCard());
			else if (second == 'F') newDeck.add(new DrawFourWildCard());
			else {
				Integer num = (int) second;
				NumberCard cardd = new NumberCard(num, color);
				cardd.setNum(num);
				newDeck.add(cardd);
			}
		}
		
		
		return newDeck;
	}
	/**
	 * 
	 * gets bot's starting hand
	 * 
	 * 
	 */
	
	private ArrayList<Card>[] getBotsStartingHand(String next){
		
		String[] stringHands = next.split("\\|");
		
		ArrayList<ArrayList<Card>> result = new ArrayList<ArrayList<Card>>();
		
		for (String hand : stringHands) {
			
			ArrayList<Card> thisHand = stringToDeck(hand);
			
			result.add(thisHand);
		}
		
		
		ArrayList<Card>[] arrayResult = new ArrayList[result.size()];
	    arrayResult = result.toArray(arrayResult);

	    return arrayResult;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
