package frames;



import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import cards.Card;
import cards.ReverseCard;
import gameCharacters.Bot;
import gameCharacters.GameCharacter;
import gameCharacters.Player;
import thyGameRunner.GameMaster;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.BoxLayout;
import javax.swing.SwingConstants;

import accountManagement.AccountWizard;

public class GameSession extends JFrame {

	private static final long serialVersionUID = 1L;
//	private JPanel contentPane;
	private GameMaster gameMaster;
	private ArrayList<GameCharacter> characterList;
	private static final Color unoRed = new Color(215, 38, 0);
	private static final Color unoBlue = new Color(9, 86, 191);
	private static final Color unoGreen = new Color(55, 151, 17);
	private static final Color unoYellow = new Color(165, 148, 5);// (236, 212, 7)
	private static final Color myTurnColor = new Color(0x0E5F4E3);
	private static final Color imBlockedColor = new Color(0x0F05365);
	private JPanel botDisplay;
	private JLabel deckSizeText;
	private JPanel playersCards;
	private JPanel playField;
	private JButton nextTurnButton;
	private JPanel contentPane;
	private JButton drawCardButton;
	private JScrollPane scrollPaneForGameField;
	private Component[] componentsOfPlayField;
	private Card lastPlayedCard;
	private int reverseInt;
	private JLabel directionOfGameLabel;
	private JLabel topCardLabel;
	private JButton sayUnoButton;
	private float probabilityOfUNOopposition;
	private String sessionName;
	private JButton saveGameButton;
	private JButton exitGameButton;
	private GameSession me;

	
	
	/**
	 * 
	 * the game is played here
	 * 
	 * @param gameMaster manages the game's overall stuff
	 * @param sessionName the name of the session
	 */
	public GameSession(GameMaster gameMaster, String sessionName) {
		
		me = this;
		setVisible(true);
		
		probabilityOfUNOopposition = (float) (1 - Math.pow(0.7, (1.0f / gameMaster.getBotCount())));
		
		this.sessionName = sessionName;
		lastPlayedCard = null;
		reverseInt = 1;
		
		this.gameMaster = gameMaster;
		characterList = gameMaster.getCharacterList();
		Player player = (Player) characterList.get(0);
		
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (screenSize.width - 800) / 2;
		int y = (screenSize.height - 600) / 2;
		setBounds(x, y, 800, 600);

		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBackground(myTurnColor);
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel playersHandBorderPanel = new JPanel();
		playersHandBorderPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		playersHandBorderPanel.setBounds(6, 6, 254, 355);
		contentPane.add(playersHandBorderPanel);
		playersHandBorderPanel.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("Your Hand");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setFont(new Font("Lucida Grande", Font.ITALIC, 13));
		lblNewLabel_3.setBounds(6, 6, 242, 16);
		playersHandBorderPanel.add(lblNewLabel_3);
		
		playersCards = new JPanel();
		playersCards.setBounds(6, 27, 242, 322);
		playersHandBorderPanel.add(playersCards);
		playersCards.setLayout(new BoxLayout(playersCards, BoxLayout.Y_AXIS));
		
		JScrollPane scrollPane = new JScrollPane(playersCards);
		scrollPane.setBounds(6, 27, 242, 322);
		playersHandBorderPanel.add(scrollPane);
		scrollPane.setBorder(null);

		
		botDisplay = new JPanel();
		botDisplay.setBorder(new LineBorder(new Color(0, 0, 0)));
		botDisplay.setBounds(540, 6, 254, 355);
		contentPane.add(botDisplay);
		botDisplay.setLayout(new GridLayout(0, 1, 0, 0));
		
		
		JPanel gameFieldPanelBorder = new JPanel();
		gameFieldPanelBorder.setBorder(new LineBorder(new Color(0, 0, 0)));
		gameFieldPanelBorder.setBounds(272, 6, 254, 355);
		contentPane.add(gameFieldPanelBorder);
		gameFieldPanelBorder.setLayout(null);
		
		
		
		JLabel lblNewLabel = new JLabel("PLAY FIELD");
		lblNewLabel.setFont(new Font("Lucida Grande", Font.ITALIC, 13));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(6, 6, 121, 16);
		gameFieldPanelBorder.add(lblNewLabel);
		
		playField = new JPanel();
		playField.setBorder(null);
		playField.setBounds(6, 34, 242, 297);
		gameFieldPanelBorder.add(playField);
		playField.setLayout(new BoxLayout(playField, BoxLayout.Y_AXIS));
		
		
		
		directionOfGameLabel = new JLabel("clockwise");
		directionOfGameLabel.setHorizontalAlignment(SwingConstants.CENTER);
		directionOfGameLabel.setFont(new Font("Lucida Grande", Font.ITALIC, 13));
		directionOfGameLabel.setBounds(127, 6, 121, 16);
		gameFieldPanelBorder.add(directionOfGameLabel);
		
		topCardLabel = new JLabel("Top Card");
		topCardLabel.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 13));
		topCardLabel.setHorizontalAlignment(SwingConstants.CENTER);
		topCardLabel.setBounds(94, 333, 154, 16);
		gameFieldPanelBorder.add(topCardLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Top Card -->");
		lblNewLabel_1.setBounds(6, 333, 87, 16);
		gameFieldPanelBorder.add(lblNewLabel_1);
		
		JPanel playersActions = new JPanel();
		playersActions.setBorder(new LineBorder(new Color(0, 0, 0)));
		playersActions.setBounds(6, 373, 788, 155);
		contentPane.add(playersActions);
		
		drawCardButton = new JButton("Draw Card");
		drawCardButton.setBounds(424, 6, 109, 29);
		drawCardButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (e.getSource() == drawCardButton && !player.isHasPlayed()) {
					
					Card[] drawnCards = gameMaster.getDeckManager().drawCard(1, player, playersCards, deckSizeText);
					Card drawnCard = drawnCards[0];
					nextTurnButton.setEnabled(true);
					nextTurnButton.setText("Next Turn");
					String currentText = "Drew a card";
					playField.add(new JLabel(player.getName() + " --> " + currentText));
					gameMaster.appendLog(player.getName() + " --> " + currentText);
					
					if (drawnCard.isPlayable()) drawCardButton.setEnabled(false);
					nextTurnButton.setText("End turn");
					
				}
			}
		});
		
		JButton didntSayUnoButton = new JButton("I wonder... What is my purpose???");
		didntSayUnoButton.setBounds(59, 6, 253, 29);
		didntSayUnoButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				GameCharacter lastPlayer = null;
				if (reverseInt == -1) {
					
					lastPlayer = characterList.get((gameMaster.getTurnIndex() + 1) % characterList.size());
				}
				else if (reverseInt == 1) {
					
					lastPlayer = characterList.get((gameMaster.getTurnIndex() - 1 + characterList.size()) % characterList.size());
				}
				
				if (lastPlayer.getCardsInHand().size() == 1 && !lastPlayer.isUNO()) {
					
					lastPlayer.penaltize(player.getName());
					
				}
				
				
			}
		});
		
		sayUnoButton = new JButton("Say UNO!");
		sayUnoButton.setBounds(317, 6, 102, 29);
		sayUnoButton.setEnabled(false);
		sayUnoButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if (player.getCardsInHand().size() == 1 && gameMaster.getTurnIndex() == 0) {
					
					player.sayUNO();
					sayUnoButton.setEnabled(false);

				}
				
				else {
					
					
				}
				
			}
		});
		
		deckSizeText = new JLabel("<deck size>");
		deckSizeText.setBounds(538, 12, 79, 16);
		
		nextTurnButton = new JButton("Your Turn");
		nextTurnButton.setBounds(622, 6, 106, 29);
		nextTurnButton.setEnabled(false);
		playersActions.setLayout(null);
		playersActions.add(didntSayUnoButton);
		playersActions.add(sayUnoButton);
		playersActions.add(drawCardButton);
		playersActions.add(deckSizeText);
		playersActions.add(nextTurnButton);
		
		JPanel sessionNameBorder = new JPanel();
		sessionNameBorder.setBounds(272, 537, 252, 29);
		sessionNameBorder.setBackground(null);
		contentPane.add(sessionNameBorder);
		sessionNameBorder.setBorder(null);
		sessionNameBorder.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JLabel sessionNameLabel = new JLabel("Session Name: " + sessionName);
		sessionNameBorder.add(sessionNameLabel);
		sessionNameLabel.setForeground(new Color(0x07e7f72));
		
		saveGameButton = new JButton("Save Game");
		saveGameButton.setBounds(677, 537, 117, 29);
		saveGameButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				AccountWizard.saveGame(player.getName(), characterList, gameMaster, gameMaster.getDeckManager(), me);
				
				
			}
		});
		contentPane.add(saveGameButton);
		
		exitGameButton = new JButton("Exit Game");
		exitGameButton.setForeground(new Color(215, 12, 0));
		exitGameButton.setBounds(8, 538, 117, 29);
		exitGameButton.setEnabled(false);
		contentPane.add(exitGameButton);
		
		
		nextTurnButton.addActionListener(new ActionListener() {
		
			
			@Override
			public void actionPerformed(ActionEvent e) { // NEXT TURN STARTS
				
				
//				
				cleanField();
				
				int turnIndex = gameMaster.getTurnIndex(); // GETS TURN INDEX
				turnIndex = turnIndex % characterList.size();
				
				if (characterList.get(gameMaster.getTurnIndex()) instanceof Bot) { // if the character is a bot
					
					Bot bot = (Bot) characterList.get(gameMaster.getTurnIndex());
					
					if (!lastPlayedCard.isSkip()) { // IF PLAYED SKIP SKIPS TURN
						
						bot.playTurn(gameMaster.getDeckManager());    // bot plays turn
					}
					else if (lastPlayedCard.isSkip() && !lastPlayedCard.getColor().equals(new Color(1,1,1))) {
						
						
						lastPlayedCard = new ReverseCard(new Color(1,1,1));
					}
					
					
					if (reverseInt == 1)   // IF REVERSED REVERSES
					gameMaster.setTurnIndex(++turnIndex);
					else if (reverseInt == -1)
					gameMaster.setTurnIndex(--turnIndex);
					
					
					if (characterList.get(gameMaster.getTurnIndex() % characterList.size()) instanceof Player) {    // next is player
						
						nextTurnButton.setEnabled(false);
						drawCardButton.setEnabled(true);
						nextTurnButton.setText("End turn");
//						System.out.println("isEnabled? " + nextTurnButton.isEnabled());
						contentPane.setBackground(myTurnColor); 
						
						if (lastPlayedCard.isSkip() && !lastPlayedCard.getColor().equals(new Color(1,1,1))) { // IF SKIPPED SKIPS TURN
							
							player.setHasPlayed(true);
							nextTurnButton.setEnabled(true);
							contentPane.setBackground(imBlockedColor);
							lastPlayedCard = new ReverseCard(new Color(1,1,1));
							
							
						}
						
					}
					
					
					else {
						
						Bot bot2 = (Bot) characterList.get(gameMaster.getTurnIndex() % characterList.size());       // next is bot

						if(lastPlayedCard.isSkip() && !lastPlayedCard.getColor().equals(new Color(1,1,1))) {
							bot2.getMyBotPanel().updateBackground(imBlockedColor);
							lastPlayedCard.setLabelledCard(new JLabel());
						}
						
						else bot2.getMyBotPanel().updateBackground(myTurnColor);
						
						
					}
					
					didntSayUnoButton.setText(bot.getName() + " didn't say UNO!");
					
					
					
					
					bot.getMyBotPanel().updateBackground(null);
					
					
				}
				
				
				else {  // if the character is not a bot so a PLAYER IS NEXT
					
					player.setHasPlayed(false);
					player.setMyTurn(true);
					if (reverseInt == 1)
						gameMaster.setTurnIndex(++turnIndex);
					else if (reverseInt == -1)
						gameMaster.setTurnIndex(--turnIndex);
					
					contentPane.setBackground(null);
					nextTurnButton.setText("Next turn");
					
					if (!player.isUNO() && player.getCardsInHand().size() == 1 && gameMaster.getTurnIndex() != 0)  {
						
						for (int i = 1; i < gameMaster.getBotCount() + 1;i++) {
							
							if (Math.random() < 0.22) { // EVERY BOT TRIES TO CATCH UNO 
								
								String catcherName = "";
								catcherName = characterList.get(i).getName();
								System.out.println(catcherName + " caught " + player.getName() + "!");
								System.out.println(player.getName() + " --> must draw 2??");
								player.penaltize(catcherName);
								player.setUNO(true);
								
								break;
							}
							
						}
						
						player.setUNO(true);
					}
					
					if (characterList.get(gameMaster.getTurnIndex() % characterList.size()) instanceof Bot) {        // next it bot
						
						Bot bot = (Bot) characterList.get(gameMaster.getTurnIndex() % characterList.size());
						if (characterList.get((gameMaster.getTurnIndex() - reverseInt) % characterList.size()) instanceof Bot){ 
							
							Bot bot2 = (Bot) characterList.get((gameMaster.getTurnIndex() - reverseInt) % characterList.size()); 
							didntSayUnoButton.setText(bot2.getName() + " didn't say UNO!");
						}
						if(lastPlayedCard.isSkip() && !lastPlayedCard.getColor().equals(new Color(1,1,1))) {
							bot.getMyBotPanel().updateBackground(imBlockedColor);
							lastPlayedCard.setLabelledCard(new JLabel());
						}
						
						else bot.getMyBotPanel().updateBackground(myTurnColor);
						
						
					}
					

					
				}
				
				
				
				
				
				
				
				
				
					
				
				
			}
		});
	}

	/**
	 * updates direction label according to the direction of the game
	 * 
	 */
	public void updateDirectionLabel() {
		
		if (reverseInt == 1) {
			directionOfGameLabel.setText("clockwise");
		}
		else if (reverseInt == -1) {
			directionOfGameLabel.setText("counter clockwise");
		}
		
	}
	
	/**
	 * makes it so that JLabels fit in the game field
	 * 
	 */
	public void cleanField() {
		
		componentsOfPlayField = playField.getComponents();
		if (componentsOfPlayField.length >= 14) {
			
			for (int i = 0; i < 10; i++) {
				
				Component comp = componentsOfPlayField[i];
				playField.remove(comp);
				
			}
			
		}
	}
	
	
	public GameMaster getGameMaster() {
		return gameMaster;
	}

	public void setGameMaster(GameMaster gameMaster) {
		this.gameMaster = gameMaster;
	}

	public ArrayList<GameCharacter> getCharacterList() {
		return characterList;
	}

	public void setCharacterList(ArrayList<GameCharacter> characterList) {
		this.characterList = characterList;
	}

	public JPanel getBotDisplay() {
		return botDisplay;
	}

	public void setBotDisplay(JPanel botDisplay) {
		this.botDisplay = botDisplay;
	}

	public JLabel getDeckSizeText() {
		return deckSizeText;
	}

	public void setDeckSizeText(JLabel deckSizeText) {
		this.deckSizeText = deckSizeText;
	}

	public JPanel getPlayersCards() {
		return playersCards;
	}

	public void setPlayersCards(JPanel playersCards) {
		this.playersCards = playersCards;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public static Color getUnored() {
		return unoRed;
	}

	public static Color getUnoblue() {
		return unoBlue;
	}

	public static Color getUnogreen() {
		return unoGreen;
	}

	public static Color getUnoyellow() {
		return unoYellow;
	}

	public JPanel getPlayField() {
		return playField;
	}

	public void setPlayField(JPanel playField) {
		this.playField = playField;
	}

	public JButton getNextTurnButton() {
		return nextTurnButton;
	}

	public void setNextTurnButton(JButton nextTurnButton) {
		this.nextTurnButton = nextTurnButton;
	}

//	public JPanel getContentPane() {      BREAKS THE GMAE
//		return contentPane;
//	}
//
//	public void setContentPane(JPanel contentPane) {
//		this.contentPane = contentPane;
//	}

	public JButton getDrawCardButton() {
		return drawCardButton;
	}

	public void setDrawCardButton(JButton drawCardButton) {
		this.drawCardButton = drawCardButton;
	}

	public static Color getMyturncolor() {
		return myTurnColor;
	}

	public JScrollPane getScrollPaneForGameField() {
		return scrollPaneForGameField;
	}

	public void setScrollPaneForGameField(JScrollPane scrollPaneForGameField) {
		this.scrollPaneForGameField = scrollPaneForGameField;
	}

	public Component[] getComponentsOfPlayField() {
		return componentsOfPlayField;
	}

	public void setComponentsOfPlayField(Component[] componentsOfPlayField) {
		this.componentsOfPlayField = componentsOfPlayField;
	}

	public Card getLastPlayedCard() {
		return lastPlayedCard;
	}

	public void setLastPlayedCard(Card lastPlayedCard) {
		topCardLabel.setText(lastPlayedCard.toString());
		topCardLabel.setForeground(lastPlayedCard.getColor());
		this.lastPlayedCard = lastPlayedCard;
	}

	public int getReverseInt() {
		return reverseInt;
	}

	public void setReverseInt(int reverseInt) {
		this.reverseInt = reverseInt;
	}

	public static Color getImblockedcolor() {
		return imBlockedColor;
	}

	public JLabel getDirectionOfGameLabel() {
		return directionOfGameLabel;
	}

	public void setDirectionOfGameLabel(JLabel directionOfGameLabel) {
		this.directionOfGameLabel = directionOfGameLabel;
	}

	public JLabel getTopCardLabel() {
		return topCardLabel;
	}

	public void setTopCardLabel(JLabel topCardLabel) {
		this.topCardLabel = topCardLabel;
	}

	public JButton getSayUnoButton() {
		return sayUnoButton;
	}

	public void setSayUnoButton(JButton sayUnoButton) {
		this.sayUnoButton = sayUnoButton;
	}

	public float getProbabilityOfUNOopposition() {
		return probabilityOfUNOopposition;
	}

	public void setProbabilityOfUNOopposition(float probabilityOfUNOopposition) {
		this.probabilityOfUNOopposition = probabilityOfUNOopposition;
	}

	public String getSessionName() {
		return sessionName;
	}

	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}
}
