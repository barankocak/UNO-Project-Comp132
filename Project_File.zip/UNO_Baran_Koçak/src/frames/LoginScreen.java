package frames;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import accountManagement.AccountWizard;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LoginScreen extends JFrame {

	private JPanel contentPane;
	private JTextField txtEnterUsername;
	private JTextField txtEnterPassword;
	private MainMenu mainMenu;
	/**
	 * Launch the application.
	 */
	
	
	
	/*
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginScreen frame = new LoginScreen();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
*/
	/**
	 * opens login screen
	 * 
	 * gets input from JTextFields nad loggs in accordingly
	 * 
	 * after succesfull login main menu opens
	 * 
	 * 
	 */
	public LoginScreen() {
		setTitle("WELCOME TO UNO!!!!");
		setResizable(false);
		setForeground(new Color(174, 239, 142));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (screenSize.width - 400) / 2;
		int y = (screenSize.height - 260) / 2;
		setBounds(x, y, 400, 260);
		
		contentPane = new JPanel();
		contentPane.setBackground(new Color(238, 238, 238));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		txtEnterUsername = new JTextField();
		txtEnterUsername.setBounds(78, 79, 277, 26);
		txtEnterUsername.setBackground(new Color(174, 239, 142));
		txtEnterUsername.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Username:");
		lblNewLabel.setBounds(6, 84, 66, 16);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setBounds(13, 128, 59, 16);
		
		txtEnterPassword = new JTextField();
		txtEnterPassword.setBounds(78, 123, 277, 26);
		txtEnterPassword.setColumns(10);
		txtEnterPassword.setBackground(new Color(174, 239, 142));
		
		JLabel warningLabel = new JLabel("");
		warningLabel.setBounds(6, 190, 388, 36);
		
		JButton loginButton = new JButton("LOGIN");
		loginButton.setBounds(119, 167, 84, 29);
		loginButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				String username = txtEnterUsername.getText();
				String password = txtEnterPassword.getText();
				AccountWizard wizard = new AccountWizard();
				
				
				if (e.getSource() == loginButton) {  // LOGIN
					
					boolean isOK;
					
					if (username.equals("")||password.equals("")) {
						
						warningLabel.setText("please fill in the blanks.");
					}
					
					else if (wizard.isRegistered(username)) { // if there exsists an account
						
						isOK = wizard.login(username, password);
						if (!isOK) {
							warningLabel.setText("wrong password");
						}
						else {
							
							
							warningLabel.setText("login succesfull");          /** EXITING LOGIN MENU **/

							mainMenu = new MainMenu(username);
							mainMenu.setVisible(isOK);
							LoginScreen.this.dispose();
						}
					}
					else {
						
						warningLabel.setText("there exists no username " + username + ". Please try again");
					}
					
				}
			}
		});
		
		JButton registerButton = new JButton("REGISTER");
		registerButton.setBounds(221, 167, 87, 29);
		registerButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { 
				
				String username = txtEnterUsername.getText();
				String password = txtEnterPassword.getText();
				AccountWizard wizard = new AccountWizard();
				
				if (e.getSource() == registerButton) { // REGISTER
				
					
					if (username.equals("")||password.equals("")) {
						
						warningLabel.setText("please fill in the blanks.");
					}
					else if (username.length() > 10) {
						
						warningLabel.setText("username cannot contain more than 10 characters");
						
					}
					
					else if (!wizard.isRegistered(username)) {
					
						wizard.register(username, password);
						warningLabel.setText("register sucesfull. now login to play the game!");
//						System.out.println("register succesfull");
						
					}
					else {
						warningLabel.setText("This account already exists: " + username);
					}
				
				}
				
				
				
			}
		});
		
		JLabel lblNewLabel_2 = new JLabel("UNO");
		lblNewLabel_2.setBounds(107, 17, 178, 50);
		lblNewLabel_2.setFont(new Font("Lucida Grande", Font.BOLD, 26));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		
		
		warningLabel.setFont(new Font("Lucida Grande", Font.BOLD, 11));
		warningLabel.setForeground(new Color(217, 76, 19));
		warningLabel.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.setLayout(null);
		contentPane.add(lblNewLabel);
		contentPane.add(lblNewLabel_1);
		contentPane.add(loginButton);
		contentPane.add(registerButton);
		contentPane.add(txtEnterPassword);
		contentPane.add(txtEnterUsername);
		contentPane.add(lblNewLabel_2);
		contentPane.add(warningLabel);
	}
}
