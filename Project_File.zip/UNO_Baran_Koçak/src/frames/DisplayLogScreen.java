package frames;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import accountManagement.AccountWizard;

import java.awt.Color;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.GridLayout;

public class DisplayLogScreen extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private String username;
	private JPanel gameSessionOptionsPanel;
	private BufferedReader reader;
	private JPanel insideLogPanel;
	private JLabel selectedLog;
	
	/**
	 * displays log screen
	 * on right the user chooses which game to display
	 * on left the choosen log
	 * 
	 * @param username the name of the user
	 */
	public DisplayLogScreen(String username) {
		
		setVisible(true);
		
		this.username = username;
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (screenSize.width - 500) / 2;
		int y = (screenSize.height - 800) / 2;
		setBounds(x, y, 500, 800);
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
		

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel logsPanel = new JPanel();
		logsPanel.setBorder(null);
		logsPanel.setBounds(6, 6, 271, 760);
		contentPane.add(logsPanel);
		logsPanel.setLayout(null);
		
		selectedLog = new JLabel("SELECT GAME TO DISPLAY");
		selectedLog.setHorizontalAlignment(SwingConstants.CENTER);
		selectedLog.setBounds(6, 6, 259, 16);
		logsPanel.add(selectedLog);
		
		insideLogPanel = new JPanel();
		insideLogPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		insideLogPanel.setBounds(6, 32, 259, 722);
		logsPanel.add(insideLogPanel);
		insideLogPanel.setLayout(new BoxLayout(insideLogPanel, BoxLayout.Y_AXIS));
		
		JScrollPane scrollPane = new JScrollPane(insideLogPanel);
		scrollPane.setBounds(6, 32, 259, 722);
		scrollPane.setBorder(null);
		logsPanel.add(scrollPane);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(289, 6, 205, 760);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		gameSessionOptionsPanel = new JPanel();
		gameSessionOptionsPanel.setBorder(new LineBorder(new Color(215, 215, 215)));
		gameSessionOptionsPanel.setBounds(6, 34, 193, 720);
		panel_1.add(gameSessionOptionsPanel);
		gameSessionOptionsPanel.setLayout(new GridLayout(20, 1, 0, 0));
		
		JLabel lblGameSessions = new JLabel("Game Sessions");
		lblGameSessions.setHorizontalAlignment(SwingConstants.CENTER);
		lblGameSessions.setBounds(6, 6, 193, 16);
		panel_1.add(lblGameSessions);
		
		algorithStuff();
		
		
		
		
	}
	
	
	/**
	 * reads file and adds mouse listener to JLabels
	 * 
	 */
	public void algorithStuff() {
		

		File[] gameFiles = AccountWizard.getAllGameFiles(username);
		
		for (int i = 0; i < gameFiles.length; i++) {
			

			File gameFile = gameFiles[i];
			File logFile = AccountWizard.getLogFile(gameFile);
			
			JLabel fileNameLabel = new JLabel();
			fileNameLabel.setText(gameFile.getName());
			Color normalColor = fileNameLabel.getForeground();
			
			fileNameLabel.addMouseListener(new MouseAdapter() {
				
				@Override
				public void  mousePressed(MouseEvent e) {
					
					selectedLog.setText(gameFile.getName());
					
					insideLogPanel.removeAll();
					insideLogPanel.revalidate();
					insideLogPanel.repaint();
					
					try {
						
						reader = new BufferedReader(new FileReader(logFile));
						String nextLine  = reader.readLine();
						int i = 0;
						Color[] colors = {Color.black,Color.gray};
						while (nextLine != null) {
							
							JLabel label = new JLabel(nextLine);
							label.setForeground(colors[i % 2]);
							
							insideLogPanel.add(label);
							nextLine  = reader.readLine();
							
							i++;
						}
						
						
						
					} catch (FileNotFoundException e1) {
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} finally {
						
						try {
							reader.close();
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					}
					
					insideLogPanel.revalidate();
					insideLogPanel.repaint();
					
					
				}
				
				
				@Override
				public void mouseEntered(MouseEvent e) {
					
					
					fileNameLabel.setForeground(new Color(0x0DF7373));
					
				}
				
				
				@Override
				public void mouseExited(MouseEvent e) {
					
					
					fileNameLabel.setForeground(normalColor);
					
					
				}
				
				
				
			});
			
			fileNameLabel.setHorizontalAlignment(SwingConstants.CENTER);
			fileNameLabel.setVerticalAlignment(SwingConstants.CENTER);
			if (logFile != null) gameSessionOptionsPanel.add(fileNameLabel);
			fileNameLabel.revalidate();
			fileNameLabel.repaint();
			
		}
			
	}

}


























