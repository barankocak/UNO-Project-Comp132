package cards;

import java.awt.Color;

import gameCharacters.GameCharacter;

/**
 * action card
 */
public abstract class ActionCard extends Card{
	
	
	
	
	
	
	/**
	 * contructor for action card
	 * @param color the color of the card
	 */
	public ActionCard(Color color) {
		
		super(color);
		type = "action";
		labeliseCard();
		isSkip = false;
		scoreValue = 20;
	}

	@Override // applies
	public abstract boolean applyCardEffect(GameCharacter nextCharacter);

}
