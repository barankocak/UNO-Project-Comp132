package cards;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;

import gameCharacters.Bot;
import gameCharacters.GameCharacter;
import gameManagement.DeckManager;

public class DrawTwoCard extends ActionCard{
	
	
	
	
	public DrawTwoCard(Color color) {
		
		super(color);
		type = "draw-two";
		labeliseCard();
		isSkip = false;
	}

	
	/**
	 * makes victim draw 2
	 * 
	 * @param nextCharacter victim
	 */
	@Override
	public boolean applyCardEffect(GameCharacter nextCharacter) {
		
		DeckManager deckManager = gameMaster.getDeckManager();
		
		deckManager.drawCard(2, nextCharacter, playersCards, gameMaster.getGameSession().getDeckSizeText());
		
		JLabel explainor = new JLabel(nextCharacter.getName() + " --> " + "must draw twice");
		Font italicFont = new Font(explainor.getFont().getName(), Font.ITALIC, explainor.getFont().getSize());
		explainor.setFont(italicFont);
		gameMaster.getGameSession().getPlayField().add(explainor);
		gameMaster.appendLog(explainor.getText());
		
		if (nextCharacter instanceof Bot) nextCharacter.getMyBotPanel().updateHandSizeText();
		
		return false;
	}
		
		
		
	

}
