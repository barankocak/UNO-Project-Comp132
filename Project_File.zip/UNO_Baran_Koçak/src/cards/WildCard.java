package cards;

import java.awt.Color;

import gameCharacters.GameCharacter;

public abstract class WildCard extends Card{
	
	public WildCard() {
	
		super(new Color(0,0,0));
		type = "Wild";
		labeliseCard();
		isSkip = false;
		scoreValue = 50;
	}
	@Override // nothing
	public abstract boolean applyCardEffect(GameCharacter nextCharacter);
	
	
	@Override
	public String toString() {
		
		return type;
	}



}
