package cards;



import gameCharacters.GameCharacter;

public class SimpleWildCard extends WildCard{

	
	
	
	public SimpleWildCard() {
		super();
		
		type = "simple-wild";
		labeliseCard();
		isSkip = false;
	}

	/**
	 * 
	 * @return true because wildCard
	 */
	@Override
	public boolean applyCardEffect(GameCharacter nextCharacter) {
		
		return true;
		
		
	}
	
	
	
	
	

}
