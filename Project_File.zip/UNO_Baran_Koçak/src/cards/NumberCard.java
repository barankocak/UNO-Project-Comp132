package cards;

import java.awt.Color;

import gameCharacters.GameCharacter;

public class NumberCard extends Card {
	
	
	// instance variables
	
	
	
	
	public NumberCard(int num, Color color) {
		
		
		super(color);
		type = "Number";
		this.num = num;
		labeliseCard();
		isSkip = false;
		scoreValue = num;
		
	}

	/**
	 * does nothing must implement 
	 */
	@Override
	public boolean applyCardEffect(GameCharacter nextCharacter) {
		
		return false;
	}
	
	@Override
	public String toString() {
		
		return colorString + " " + num;
	}


	public int getNum() {
		return num;
	}




	public void setNum(int num) {
		this.num = num;
	}




	public Color getColor() {
		return color;
	}




	public void setColor(Color color) {
		this.color = color;
	}

}
