package cards;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;

import gameCharacters.GameCharacter;

public class SkipCard extends ActionCard{

	public SkipCard(Color color) {
		super(color);
		type = "skip";
		labeliseCard();
		isSkip = true;
	}

	
	/**
	 * makes victim skip turn
	 * 
	 * @param nextCharacter victim
	 */
	@Override
	public boolean applyCardEffect(GameCharacter nextCharacter) {
		
		JLabel explainor = new JLabel(nextCharacter.getName() + " --> " + "must skip it's turn");
		Font italicFont = new Font(explainor.getFont().getName(), Font.ITALIC, explainor.getFont().getSize());
		explainor.setFont(italicFont);
		gameMaster.getGameSession().getPlayField().add(explainor);
		gameMaster.appendLog(explainor.getText());
		
		return false;
	}

}
