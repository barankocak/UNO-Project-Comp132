package cards;

import java.awt.Font;

import javax.swing.JLabel;

import gameCharacters.Bot;
import gameCharacters.GameCharacter;
import gameManagement.DeckManager;

public class DrawFourWildCard extends WildCard{
	
	
	public DrawFourWildCard() {
		super();
		
		type = "draw-four-wild";
		labeliseCard();
		isSkip = false;
		
	}
	/**
	 * makes next char draw 4
	 * 
	 * @param nextCharacter the victim
	 */
	@Override
	public boolean applyCardEffect(GameCharacter nextCharacter) {
		
		DeckManager deckManager = gameMaster.getDeckManager();
		
		deckManager.drawCard(4, nextCharacter, playersCards, gameMaster.getGameSession().getDeckSizeText());
		
		JLabel explainor = new JLabel(nextCharacter.getName() + " --> " + "must draw 4 times");
		Font italicFont = new Font(explainor.getFont().getName(), Font.ITALIC, explainor.getFont().getSize());
		explainor.setFont(italicFont);
		gameMaster.getGameSession().getPlayField().add(explainor);
		gameMaster.appendLog(explainor.getText());
		
		if (nextCharacter instanceof Bot) nextCharacter.getMyBotPanel().updateHandSizeText();
		
		return true;
		
		
		
		
//		DeckManager deckManager = gameMaster.getDeckManager();
//		
//		deckManager.drawCard(2, nextCharacter, playersCards, gameMaster.getGameSession().getDeckSizeText());
//		
//		JLabel explainor = new JLabel(nextCharacter.getName() + " --> " + "must draw twice");
//		Font italicFont = new Font(explainor.getFont().getName(), Font.ITALIC, explainor.getFont().getSize());
//		explainor.setFont(italicFont);
//		gameMaster.getGameSession().getPlayField().add(explainor);
//		
//		if (nextCharacter instanceof Bot) nextCharacter.getMyBotPanel().updateHandSizeText();
//		
//		return false;
	}

}
