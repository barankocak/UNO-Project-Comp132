package cards;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;

import gameCharacters.GameCharacter;

public class ReverseCard extends ActionCard{



	public ReverseCard(Color color) {
		super(color);
		type = "reverse";
		labeliseCard();
		isSkip = false;
	}

	/**
	 * makes the game direction reverse of it
	 * +1 clockwise -1 counter clockwise
	 * 
	 */
	@Override
	public boolean applyCardEffect(GameCharacter nextCharacter) {
		
		gameMaster.getGameSession().setReverseInt(gameMaster.getGameSession().getReverseInt() * - 1);
		gameMaster.getGameSession().updateDirectionLabel();
		
		JLabel explainor = new JLabel(gameMaster.getGameSession().getReverseInt() > 0 ? "direction --> clockwise" : "direction --> counter clockwise");
		Font italicFont = new Font(explainor.getFont().getName(), Font.ITALIC, explainor.getFont().getSize());
		explainor.setFont(italicFont);
		gameMaster.getGameSession().getPlayField().add(explainor);
		gameMaster.appendLog(explainor.getText());
		
		return false;
	}

}
