package cards;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import frames.GameSession;
import gameCharacters.GameCharacter;
import gameCharacters.Player;
import gameManagement.DeckManager;
import thyGameRunner.GameMaster;

public abstract class Card {
	
	protected Color color;
	protected String type;
	protected int num;
	protected JPanel playField;
	protected JPanel playersCards;
	protected JLabel labelledCard;
	protected boolean isPlayed;
	protected Player player;
	protected String colorString;
	public static ArrayList<Card> playedCards = new ArrayList<>();
	protected GameMaster gameMaster;
	protected Card me;
	protected boolean isSkip;
	protected static boolean isPlayersTurn;
	protected int scoreValue;
	
	/**
	 * contructor for card
	 * 
	 * @param color color of the card
	 */
	public Card(Color color) {
		
		this.color = color;
		type = "card";
		isPlayed = false;
		labeliseCard();
		me = this;
		isSkip = false;
	}
	
	/**
	 * turns cards into JLabels that are going to be interactable and will act as cards.
	 * 
	 */
	public void labeliseCard() {
		
		gimmeColor();
		isPlayersTurn = true;
		labelledCard = new JLabel(this.toString());
		labelledCard.addMouseListener(new MouseAdapter() {
			
			@Override
			public void  mousePressed(MouseEvent e) {
				
				if ((gameMaster.getGameSession().getReverseInt() == 1 && (gameMaster.getTurnIndex() % gameMaster.getCharacterList().size()) == 0)){
					
					isPlayersTurn = true;
					
				}
				
				else if (gameMaster.getGameSession().getReverseInt() == -1 && (gameMaster.getTurnIndex() % gameMaster.getCharacterList().size()) == 0) {
					
					isPlayersTurn = true;
				}
				else isPlayersTurn = false;
				
				
				
				if (!isPlayed && isPlayersTurn) {
					playPlayersCard();
				}
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				
				if ((gameMaster.getGameSession().getReverseInt() == 1 && (gameMaster.getTurnIndex() % gameMaster.getCharacterList().size()) == 0)){
					
					isPlayersTurn = true;
					
				}
				
				else if (gameMaster.getGameSession().getReverseInt() == -1 && (gameMaster.getTurnIndex() % gameMaster.getCharacterList().size()) == 0) {
					
					isPlayersTurn = true;
				}
				else isPlayersTurn = false;
				
				
				// turns the brigtness up
				
			    if (!isPlayed && isPlayersTurn && !player.isHasPlayed()) {
			        Color currentColor = labelledCard.getForeground();
			        
			        float[] hsb = Color.RGBtoHSB(currentColor.getRed(), currentColor.getGreen(), currentColor.getBlue(), null);
			        float brightness = hsb[2];
			        brightness += 0.5f;
			        labelledCard.setForeground(Color.getHSBColor(hsb[0], hsb[1], brightness));
			        
			    }
			}

			@Override
			public void mouseExited(MouseEvent e) {
			    labelledCard.setForeground(Color.black);
			}
			
		});
		
	}
	
	/**
	 * if the card is playable and the player has not played it plays the card.
	 * Converts the card name to what will be displayed in game field and log
	 * 
	 * 
	 * 
	 */
	public void playPlayersCard() {
		
		
		
		if (isPlayable() && !player.isHasPlayed()) {
			
			gameMaster.getGameSession().getSayUnoButton().setEnabled(true);
			
			gameMaster.getGameSession().setLastPlayedCard(me);
			isPlayed = true;
			playField.add(labelledCard);
			playField.revalidate();
	        playField.repaint();
			
	        playersCards.remove(labelledCard);
	        playersCards.revalidate();
	        playersCards.repaint();
	        if (isPlayed) {
	        	
	        	String currentText = labelledCard.getText();
	            labelledCard.setText(player.getName() + " --> " + currentText);
	            gameMaster.appendLog(labelledCard.getText());
	        }
	        playedCards.add(this);
	        player.getCardsInHand().remove(this);
	        
	        gameMaster.getGameSession().getNextTurnButton().setEnabled(true);
	        gameMaster.getGameSession().getDrawCardButton().setEnabled(false);
	        player.setHasPlayed(true);
	        gameMaster.getGameSession().getNextTurnButton().setText("End turn");
	        
	        GameCharacter nextCharacter = null;
	        
	        if (gameMaster.getGameSession().getReverseInt() == 1) {
	        	
	        	nextCharacter = gameMaster.getCharacterList().get(1);
	        }
	        else if (gameMaster.getGameSession().getReverseInt() == -1) {
	        	
	        	nextCharacter = gameMaster.getCharacterList().get(gameMaster.getCharacterList().size() - 1);
	        }
	        
	        boolean isWild;
	        
	        isWild = applyCardEffect(nextCharacter);
	        
	        if (isWild) {
	        	
	        	showWildChoice();
	        }
	        
	        if (player.getCardsInHand().size() == 0) {
	        	
	        	player.win();
	        }
		}
		
		
		
	}
	/**
	 * plays bots card and changes text like playPlayersCard()
	 * itarates over cards and plays the first playable one
	 * chooses wildcard color of the most of what he has
	 * 
	 * @param bot the bot that is going to play
	 */
	public void playBotsCard(GameCharacter bot) {
		
		isPlayed = true;                
		playField.add(labelledCard);
		playField.revalidate();
        playField.repaint();
        
        if (isPlayed) {
        	
        	String currentText = labelledCard.getText();
            labelledCard.setText(bot.getName() + " --> " + currentText);
            gameMaster.appendLog(labelledCard.getText());
        }
        playedCards.add(this);
        bot.getCardsInHand().remove(this);
        bot.getMyBotPanel().updateHandSizeText();
        
        GameCharacter nextCharacter = null;
        
        for (int i = 0; i < gameMaster.getCharacterList().size(); i++) {
        	
        	GameCharacter character = gameMaster.getCharacterList().get(i % gameMaster.getCharacterList().size());
        	
        	if (character.equals(bot)) {
        		if (gameMaster.getGameSession().getReverseInt() == 1) {
        			
        			nextCharacter = gameMaster.getCharacterList().get(++i % gameMaster.getCharacterList().size());
        		}
        		else if (gameMaster.getGameSession().getReverseInt() == -1) {
        			
        			nextCharacter = gameMaster.getCharacterList().get((--i + gameMaster.getCharacterList().size()) % gameMaster.getCharacterList().size());
        		}
        		
        		break;
        	}
        }
        
        boolean isWild;
        
        isWild = applyCardEffect(nextCharacter);
        
        JLabel explain = new JLabel(me.toString() + "--> " + colorString);
        
        // wild card AI
        if (isWild) {
        	
        	
        	int r = 0;
        	int b = 0;
        	int g = 0;
        	int y = 0;
        	
        	for (int i = 0; i < bot.getCardsInHand().size(); i++) {
        		
        		String thisColor = bot.getCardsInHand().get(i).getColorString();
        		
        		if (thisColor.equals("red")) r++;
        		else if (thisColor.equals("yellow")) y++;
        		else if (thisColor.equals("green")) g++;
        		else if (thisColor.equals("blue")) b++;
        	}
        	
        	String frequentColor = "";
        	Color freqcol = null;
        	int mostFrequent = -10;

        	if (r > mostFrequent) {
        	    mostFrequent = r;
        	    frequentColor = "red";
        	    freqcol = GameSession.getUnored();
        	}
        	if (y > mostFrequent) {
        	    mostFrequent = y;
        	    frequentColor = "yellow";
        	    freqcol = GameSession.getUnoyellow();
        	}
        	if (g > mostFrequent) {
        	    mostFrequent = g;
        	    frequentColor = "green";
        	    freqcol = GameSession.getUnogreen();
        	}
        	if (b > mostFrequent) {
        	    mostFrequent = b;
        	    frequentColor = "blue";
        	    freqcol = GameSession.getUnoblue();
        	}
        	color = freqcol;
        	colorString = frequentColor;
        	explain.setForeground(freqcol);
        	explain.setText(me.toString() + "--> " + colorString);
        	gameMaster.getGameSession().getPlayField().add(explain);
        	explain.revalidate();
        	explain.repaint();
        	gameMaster.appendLog(explain.getText());
        	gameMaster.getGameSession().setLastPlayedCard(me);
        	
        	
        }
	}
	
	/**
	 *  when bot draws a card it displays in the game field
	 *  
	 * @param bot the one who draws
	 * @param drawnCardNum how many cards are drawn
	 */
	public void imDrawn(GameCharacter bot, int drawnCardNum) {
		
		String currentText;
		
		if (drawnCardNum == 1) currentText = "Drew a card";
		else currentText = "Drew" + drawnCardNum + "card";
		
		String printString = bot.getName() + " --> " + currentText;
		
        gameMaster.getGameSession().getPlayField().add(new JLabel(printString));
        gameMaster.appendLog(printString);
		
	}
	
	
	/**
	 * initializes colorString
	 */
	public void gimmeColor() {
		
		if (color.equals(DeckManager.getColors()[0])) {
	        colorString = "red";
	    } else if (color.equals(DeckManager.getColors()[1])) {
	        colorString = "blue";
	    } else if (color.equals(DeckManager.getColors()[2])) {
	        colorString = "green";
	    } else if (color.equals(DeckManager.getColors()[3])) {
	        colorString = "yellow";   
	    }
	    else colorString = "black";
	}
	
	/**
	 * checks if the card is playable
	 * 
	 * @return true if playable
	 */
	public boolean isPlayable() {
		
		if (playedCards.size() == 0) {
			return true;
			
		}
		
		
		Card topCard = playedCards.get(playedCards.size() - 1);
		boolean playable = true;
		
		if (topCard.getColor() == null) return true;
		
		
		if (this instanceof WildCard) {
			
			playable = true; 
			
		}
		else if (topCard instanceof WildCard) {
			
			
			if (topCard.getColor().equals(color)) {
				
				playable = true;
			}
			
			else playable = false;
		
		}
		else if (topCard instanceof NumberCard) {
			
			if (topCard.getColor().equals(color) || topCard.getNum() == num) {
				
				playable = true;
			}
			else playable = false;
		}
		else if (topCard instanceof ActionCard) {
			
			if (topCard.getColor().equals(color) || topCard.getType().equals(type)) {
				
				playable = true;
			}
			else playable = false;
			
		}
		
		return playable;
	}
	/**
	 * Applies card effect
	 * 
	 * @param nextCharacter the upcoming character that is the victim of the card
	 * @return reutrns true if wild card
	 */
	public abstract boolean applyCardEffect(GameCharacter nextCharacter);
	
	/**
	 * popps a message to choose the color of the wild card
	 * 
	 * @return true if successfull
	 */
	public boolean showWildChoice() {
		
		
        Object[] options = {"Blue", "Red", "Yellow", "Green"};

        
        int choice = JOptionPane.showOptionDialog(gameMaster.getGameSession(), "Select a color for wild card:", "SELECT COLOR", JOptionPane.DEFAULT_OPTION,
        		JOptionPane.PLAIN_MESSAGE, null, options, null);

        
        JLabel explain = new JLabel(me.toString() + "--> " + colorString);
        
        
        
         if (choice == 0) {
        	
            System.out.println("clicked Blue");
            color = GameSession.getUnoblue();
            colorString = "blue";
            explain.setForeground(color);
            explain.setText(me.toString() + "--> " + colorString);
            gameMaster.getGameSession().getPlayField().add(explain);
            explain.revalidate();
            explain.repaint();
            gameMaster.appendLog(explain.getText());
            
            
        } else if (choice == 1) {
        	
            System.out.println("clicked Red");
            color = GameSession.getUnored();
            colorString = "red";
            explain.setForeground(color);
            explain.setText(me.toString() + "--> " + colorString);
            gameMaster.getGameSession().getPlayField().add(explain);
            explain.revalidate();
            explain.repaint();
            gameMaster.appendLog(explain.getText());
            
        } else if (choice == 2) {
        	
            System.out.println("clicked Yellow");
            color = GameSession.getUnoyellow();
            colorString = "yellow";
            explain.setForeground(color);
            explain.setText(me.toString() + "--> " + colorString);
            gameMaster.getGameSession().getPlayField().add(explain);
            explain.revalidate();
            explain.repaint();
            gameMaster.appendLog(explain.getText());
            
        } else if (choice == 3) {
        	
            System.out.println("clicked Green");
            color = GameSession.getUnogreen();
            colorString = "green";
            explain.setForeground(color);
            explain.setText(me.toString() + "--> " + colorString);
            gameMaster.getGameSession().getPlayField().add(explain);
            explain.revalidate();
            explain.repaint();
            gameMaster.appendLog(explain.getText());
            
        }
        
		gameMaster.getGameSession().setLastPlayedCard(me);
		
		return true;
		
		
	}
	
	
	
	@Override
	public String toString() {
		return colorString + " " + type;
	}
	
	
	
	
	
	
	
	
	
	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}


	public JPanel getPlayField() {
		return playField;
	}


	public boolean isSkip() {
		return isSkip;
	}

	public void setSkip(boolean isSkip) {
		this.isSkip = isSkip;
	}

	public void setPlayField(JPanel playField) {
		this.playField = playField;
	}


	public JLabel getLabelledCard() {
		return labelledCard;
	}


	public void setLabelledCard(JLabel labelledCard) {
		this.labelledCard = labelledCard;
	}

	public JPanel getPlayersCards() {
		return playersCards;
	}

	public void setPlayersCards(JPanel playersCards) {
		this.playersCards = playersCards;
	}

	public boolean isPlayed() {
		return isPlayed;
	}

	public void setPlayed(boolean isPlayed) {
		this.isPlayed = isPlayed;
	}

	public Player getPlayer() {
		return player;
	}

	public void setPlayer(Player player) {
		this.player = player;
	}

	public String getColorString() {
		return colorString;
	}

	public void setColorString(String colorString) {
		this.colorString = colorString;
	}

	public static ArrayList<Card> getPlayedCards() {
		return playedCards;
	}

	public static void setPlayedCards(ArrayList<Card> playedCards) {
		Card.playedCards = playedCards;
	}

	public GameMaster getGameMaster() {
		return gameMaster;
	}

	public void setGameMaster(GameMaster gameMaster) {
		this.gameMaster = gameMaster;
	}

	public static boolean isPlayersTurn() {
		return isPlayersTurn;
	}

	public static void setPlayersTurn(boolean isPlayersTurn) {
		Card.isPlayersTurn = isPlayersTurn;
	}

	public int getScoreValue() {
		return scoreValue;
	}

	public void setScoreValue(int scoreValue) {
		this.scoreValue = scoreValue;
	}

	
	
}
